# GenieACS Pro

Dashboard manajemen ISP modern di atas GenieACS. Frontend React + TypeScript,
backend Node.js + Express + TypeScript, PostgreSQL, Nginx, Docker.

## Status

Tahap 0 (fondasi) selesai. Integrasi NBI diverifikasi lewat `nbi:check`
sebelum fitur lain dibangun.

## Arsitektur

Browser -> Nginx (HTTPS) -> React -> Express backend -> GenieACS NBI (:7557)
                                            -> PostgreSQL (akun, pelanggan, audit)

## Port GenieACS

| Komponen | Port | Keterangan |
|---|---|---|
| CWMP | 7547 | Perangkat CPE melapor |
| NBI  | 7557 | REST API - dipakai dashboard ini |
| Web UI | 3000 | UI bawaan GenieACS (bukan dipakai aplikasi ini) |

NBI **tidak boleh** diekspos ke internet. Backend di host yang sama -> loopback.

## Langkah 0 - verifikasi NBI (lakukan dulu)

```bash
cd backend
cp ../.env.example .env
npm install
npm run nbi:check
```

`nbi:check` hanya melakukan GET (read-only, aman). Jika `/devices` gagal,
periksa apakah NBI bind ke interface yang benar dan port 7557 tidak
diblokir firewall.

## Selanjutnya

- Tahap 1: Prisma schema, auth, RBAC, bootstrap admin
- Tahap 2: service NBI + routes read-only
- Tahap 3+: devices, customers, Wi-Fi, tasks, audit, Docker/Nginx, tests