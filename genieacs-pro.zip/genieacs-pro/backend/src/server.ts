import { createApp, disconnectAll } from "./app.js";
import { config } from "./config/index.js";
import { logger } from "./utils/logger.js";

async function main(): Promise<void> {
  const app = createApp();
  const server = app.listen(config.port, () => {
    logger.info(
      { port: config.port, env: config.env, nbi: config.nbi.effectiveUrl },
      "GenieACS Pro backend listening",
    );
  });

  const shutdown = (signal: string) => {
    logger.info({ signal }, "shutting down");
    server.close(async () => {
      await disconnectAll();
      process.exit(0);
    });
    // Force exit if lingering connections.
    setTimeout(() => process.exit(1), 10_000).unref();
  };

  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}

void main();
