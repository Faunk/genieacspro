import express from "express";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import { pinoHttp } from "pino-http";
import { config } from "./config/index.js";
import { logger } from "./utils/logger.js";
import { authRouter } from "./routes/auth.routes.js";
import { healthRouter } from "./routes/health.routes.js";
import { dashboardRouter } from "./routes/dashboard.routes.js";
import { devicesRouter } from "./routes/devices.routes.js";
import { customersRouter } from "./routes/customers.routes.js";
import { notFoundHandler, errorHandler } from "./middleware/errorHandler.js";
import { requireAuth } from "./middleware/auth.js";
import { prisma } from "./database/prisma.js";

export function createApp() {
  const app = express();

  if (config.trustProxyHops !== undefined) app.set("trust proxy", config.trustProxyHops);

  app.use(helmet());
  app.use(express.json({ limit: "1mb" }));
  app.use(cookieParser(config.session.secret));

  // Structured request logging; skip noisy health probes.
  app.use(
    pinoHttp({
      logger,
      autoLogging: { ignore: (req) => req.url?.startsWith("/api/health") ?? false },
    }),
  );

  // No CORS wildcard. The SPA is served by Nginx under the same origin (or via /api),
  // so no cross-origin access is needed. If you must add CORS, list explicit origins.

  app.use("/api/health", healthRouter);
  app.use("/api/auth", authRouter);
  app.use("/api/dashboard", dashboardRouter);
  app.use("/api/devices", devicesRouter);
  app.use("/api/customers", customersRouter);

  app.get("/api/me/whoami", requireAuth, (req, res) => {
    res.json({ data: req.user });
  });

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}

/** Graceful shutdown hook used by server.ts. */
export async function disconnectAll(): Promise<void> {
  await prisma.$disconnect();
}
