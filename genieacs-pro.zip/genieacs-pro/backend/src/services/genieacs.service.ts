import { config } from "../config/index.js";
import { Errors } from "../utils/errors.js";
import { logger } from "../utils/logger.js";

/**
 * The ONLY module that talks to GenieACS NBI.
 * Everything else goes through these functions.
 *
 * Design notes:
 *  - Uses native fetch with AbortController timeout.
 *  - Never retries reboot/factoryReset (dangerous).
 *  - Distinguishes network failure / timeout / HTTP error / param error.
 *  - Encodes device ids with encodeURIComponent (ids contain '-' and '.').
 */

interface NbiRequestOptions {
  method?: "GET" | "POST" | "PUT" | "DELETE";
  body?: unknown;
  query?: Record<string, string | number | undefined>;
  timeoutMs?: number;
}

/** A raw device document from GenieACS. Values live under `_value`. */
export interface GenieacsDevice {
  _id: string;
  _deviceId?: {
    _Manufacturer?: string;
    _OUI?: string;
    _ProductClass?: string;
    _SerialNumber?: string;
  };
  _lastInform?: string;
  _registered?: string;
  [key: string]: unknown;
}

export interface ParameterRow {
  path: string;
  value: string | number | boolean | null;
  type: string | null;
  writable: boolean | null;
  updatedAt: string | null;
}

/** Projection that gives us list columns without pulling full parameter trees. */
export const DEVICE_LIST_PROJECTION = [
  "_id",
  "_lastInform",
  "_registered",
  "_deviceId",
  "VirtualParameters.RXPower",
  "VirtualParameters.pppoeUsername",
  "VirtualParameters.pppUsername",
  "InternetGatewayDevice.WANDevice.WANConnectionDevice.WANPPPConnection.Username",
  "InternetGatewayDevice.DeviceInfo.Manufacturer",
  "InternetGatewayDevice.DeviceInfo.ModelName",
  "InternetGatewayDevice.DeviceInfo.ProductClass",
  "InternetGatewayDevice.DeviceInfo.HardwareVersion",
  "InternetGatewayDevice.DeviceInfo.SoftwareVersion",
  "InternetGatewayDevice.WANDevice",
  "Device.PPP.Interface.Username",
  "Device.DeviceInfo.Manufacturer",
  "Device.DeviceInfo.ModelName",
  "Device.DeviceInfo.ProductClass",
  "Device.DeviceInfo.HardwareVersion",
  "Device.DeviceInfo.SoftwareVersion",
  "Device.Optical.Interface",
  "InternetGatewayDevice.WANDevice.1.WANEponInterfaceConfig",
  "InternetGatewayDevice.WANDevice.1.WANGponInterfaceConfig",
  "InternetGatewayDevice.WANDevice.1.X_CT-COM_EponInterfaceConfig",
  "InternetGatewayDevice.WANDevice.1.X_CT-COM_GponInterfaceConfig",
  "InternetGatewayDevice.DeviceInfo.TemperatureStatus.TransceiverTemperature",
] as const;

function buildUrl(path: string, query?: Record<string, string | number | undefined>): string {
  const base = config.nbi.effectiveUrl.replace(/\/+$/, "");
  const url = new URL(base + path);
  if (query) {
    for (const [k, v] of Object.entries(query)) {
      if (v !== undefined) url.searchParams.set(k, String(v));
    }
  }
  return url.toString();
}

async function nbiRequest<T>(path: string, opts: NbiRequestOptions = {}): Promise<T> {
  const url = buildUrl(path, opts.query);
  const timeoutMs = opts.timeoutMs ?? config.nbi.timeoutMs;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  let res: Response;
  try {
    res = await fetch(url, {
      method: opts.method ?? "GET",
      headers: {
        Accept: "application/json",
        ...(opts.body !== undefined ? { "Content-Type": "application/json" } : {}),
      },
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
      signal: controller.signal,
    });
  } catch (err) {
    clearTimeout(timer);
    if (err instanceof Error && err.name === "AbortError") {
      logger.warn({ url, timeoutMs }, "NBI request timeout");
      throw Errors.nbiTimeout();
    }
    logger.error({ url, err: String(err) }, "NBI network failure");
    throw Errors.nbiUnreachable();
  } finally {
    clearTimeout(timer);
  }

  const text = await res.text();
  if (!res.ok) {
    logger.warn({ url, status: res.status, body: text.slice(0, 500) }, "NBI HTTP error");
    throw Errors.nbiHttp(res.status, `NBI error ${res.status}`, { body: text.slice(0, 500) });
  }
  if (!text) return undefined as T;
  try {
    return JSON.parse(text) as T;
  } catch {
    throw Errors.nbiHttp(502, "NBI mengembalikan respons bukan JSON");
  }
}

/** List devices (already projected/paginated). */
export async function listDevices(args: {
  query?: Record<string, unknown>;
  projection?: readonly string[];
  limit?: number;
  skip?: number;
  // GenieACS NBI expects `sort` as JSON: {"lastInform":-1}. Use plain field
  // names (no leading underscore); direction -1 desc, 1 asc.
  sort?: Record<string, 1 | -1>;
}): Promise<GenieacsDevice[]> {
  const query: Record<string, string | number | undefined> = {};
  if (args.query) query.query = JSON.stringify(args.query);
  if (args.projection) query.projection = args.projection.join(",");
  if (args.limit !== undefined) query.limit = args.limit;
  if (args.skip !== undefined) query.skip = args.skip;
  if (args.sort) query.sort = JSON.stringify(args.sort);
  return nbiRequest<GenieacsDevice[]>("/devices", { query });
}

/** Fetch a single device document by its full GenieACS _id. */
export async function getDevice(deviceId: string): Promise<GenieacsDevice> {
  if (!deviceId) throw Errors.badRequest("Device ID kosong");
  // NBI uses `_id` as a query filter for single-document fetch.
  const docs = await nbiRequest<GenieacsDevice[]>("/devices", {
    query: { query: JSON.stringify({ _id: deviceId }), limit: 1 },
  });
  const doc = docs[0];
  if (!doc) throw Errors.notFound("Perangkat tidak ditemukan di GenieACS");
  return doc;
}

/** Detect TR-181 (Device.*) vs TR-098 (InternetGatewayDevice.*). */
export function detectDataModel(doc: GenieacsDevice): "TR-181" | "TR-098" | "unknown" {
  if ((doc as Record<string, unknown>)["Device"]) return "TR-181";
  if ((doc as Record<string, unknown>)["InternetGatewayDevice"]) return "TR-098";
  return "unknown";
}

/** Read a single parameter's value by dotted path (returns undefined if absent). */
export function getParam(doc: GenieacsDevice, dottedPath: string): string | undefined {
  const parts = dottedPath.split(".");
  let node: unknown = doc;
  for (const p of parts) {
    if (node == null || typeof node !== "object") return undefined;
    node = (node as Record<string, unknown>)[p];
  }
  if (node && typeof node === "object" && "_value" in (node as Record<string, unknown>)) {
    const v = (node as Record<string, unknown>)._value;
    return v == null ? undefined : String(v);
  }
  if (node != null && typeof node !== "object") return String(node);
  return undefined;
}

/**
 * Flatten a device document into a list of parameter rows.
 * Traverses arbitrary TR-098/TR-181 tree shapes; instances (numbered) included.
 * Captures `_value`, `_type`, `_writable`, `_timestamp` when present.
 */
export function flattenParameters(doc: GenieacsDevice): ParameterRow[] {
  const rows: ParameterRow[] = [];

  const walk = (node: unknown, path: string): void => {
    if (node == null || typeof node !== "object") return;
    const obj = node as Record<string, unknown>;

    if ("_value" in obj) {
      const rawVal = obj["_value"];
      const type = typeof obj["_type"] === "string" ? (obj["_type"] as string) : null;
      const writable = typeof obj["_writable"] === "boolean" ? (obj["_writable"] as boolean) : null;
      const ts = typeof obj["_timestamp"] === "string" ? (obj["_timestamp"] as string) : null;
      rows.push({
        path,
        value:
          rawVal == null
            ? null
            : typeof rawVal === "object"
              ? JSON.stringify(rawVal)
              : (rawVal as string | number | boolean),
        type,
        writable,
        updatedAt: ts,
      });
      // An object may both have _value and children (rare); keep walking.
    }

    for (const [key, child] of Object.entries(obj)) {
      if (key.startsWith("_")) continue; // internal metadata, not a param name
      walk(child, path ? `${path}.${key}` : key);
    }
  };

  walk(doc, "");
  return rows;
}

/** Create an async task for a device (reboot, refreshObject, setParameterValues, factoryReset). */
export async function createDeviceTask(
  deviceId: string,
  task: Record<string, unknown>,
  connectionRequest = true,
): Promise<unknown> {
  if (!deviceId) throw Errors.badRequest("Device ID kosong");
  const encId = encodeURIComponent(deviceId);
  const query = connectionRequest ? { connection_request: "" } : undefined;
  return nbiRequest(`/devices/${encId}/tasks`, {
    method: "POST",
    body: task,
    query,
  });
}

/** NBI connectivity probe for the health/status endpoints. */
export async function probeNbi(): Promise<{
  ok: boolean;
  latencyMs: number;
  checkedAt: string;
  error?: string;
}> {
  const start = Date.now();
  try {
    await nbiRequest("/devices", { query: { limit: 1, projection: "_id" }, timeoutMs: 5000 });
    return { ok: true, latencyMs: Date.now() - start, checkedAt: new Date().toISOString() };
  } catch (err) {
    return {
      ok: false,
      latencyMs: Date.now() - start,
      checkedAt: new Date().toISOString(),
      error: err instanceof Error ? err.message : "unknown error",
    };
  }
}
