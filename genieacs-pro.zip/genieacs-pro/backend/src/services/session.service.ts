import crypto from "node:crypto";
import type { Response } from "express";
import { prisma } from "../database/prisma.js";
import { config } from "../config/index.js";

/** Create a server-side session and set the HttpOnly cookie. */
export async function createSession(
  res: Response,
  userId: string,
  meta: { userAgent?: string; ip?: string },
): Promise<string> {
  const id = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + config.session.ttlHours * 3600_000);

  await prisma.session.create({
    data: {
      id,
      userId,
      expiresAt,
      userAgent: meta.userAgent?.slice(0, 300) ?? null,
      ip: meta.ip ?? null,
    },
  });

  res.cookie(config.session.cookieName, id, {
    httpOnly: true,
    secure: config.session.secure,
    sameSite: config.session.sameSite,
    expires: expiresAt,
    path: "/",
  });

  return id;
}

/** Destroy a session and clear the cookie. */
export async function destroySession(res: Response, sessionId: string | undefined): Promise<void> {
  if (sessionId) {
    await prisma.session.delete({ where: { id: sessionId } }).catch(() => undefined);
  }
  res.clearCookie(config.session.cookieName, { path: "/" });
}

/** Housekeeping: delete expired sessions. */
export async function purgeExpiredSessions(): Promise<number> {
  const res = await prisma.session.deleteMany({ where: { expiresAt: { lt: new Date() } } });
  return res.count;
}
