import type { Request } from "express";
import { prisma } from "../database/prisma.js";
import type { RoleName } from "../config/permissions.js";
import { logger } from "../utils/logger.js";

interface AuditInput {
  req?: Request;
  userId?: string | null;
  userRole?: RoleName | null;
  action: string;
  targetType?: string;
  targetId?: string;
  result?: "SUCCESS" | "FAILURE" | "DENIED";
  summary?: string;
  metadata?: Record<string, unknown>;
}

/**
 * Write an audit entry. Never include secrets in summary/metadata.
 * Client IP is taken from req.ip (trust proxy configured in server).
 */
export async function writeAudit(input: AuditInput): Promise<void> {
  try {
    await prisma.auditLog.create({
      data: {
        userId: input.userId ?? null,
        userRole: (input.userRole ?? null) as never,
        action: input.action,
        targetType: input.targetType ?? null,
        targetId: input.targetId ?? null,
        result: (input.result ?? "SUCCESS") as never,
        ip: input.req?.ip ?? null,
        summary: input.summary ?? null,
        metadata: (input.metadata ?? undefined) as never,
      },
    });
  } catch (err) {
    // Auditing must never break the request path.
    logger.error({ err, action: input.action }, "failed to write audit log");
  }
}
