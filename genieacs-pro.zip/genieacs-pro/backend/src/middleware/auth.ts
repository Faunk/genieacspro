import type { NextFunction, Request, Response } from "express";
import { prisma } from "../database/prisma.js";
import { Errors } from "../utils/errors.js";
import type { Permission, RoleName } from "../config/permissions.js";
import { hasPermission } from "../config/permissions.js";

/**
 * Resolve the session from the cookie, load the user, and attach req.user.
 * Sessions are server-side (opaque id) and expire. Disabled users are rejected.
 */
export async function requireAuth(req: Request, _res: Response, next: NextFunction): Promise<void> {
  try {
    const sessionId = req.cookies?.["gpro_sid"] as string | undefined;
    if (!sessionId) throw Errors.unauthorized();

    const session = await prisma.session.findUnique({
      where: { id: sessionId },
      include: { user: true },
    });
    if (!session || session.expiresAt.getTime() < Date.now()) {
      throw Errors.unauthorized("Sesi berakhir, silakan login kembali");
    }
    if (session.user.status !== "ACTIVE") {
      throw Errors.forbidden("Akun dinonaktifkan");
    }

    req.user = {
      id: session.user.id,
      email: session.user.email,
      name: session.user.name,
      role: session.user.role as RoleName,
    };
    req.sessionId = session.id;
    next();
  } catch (err) {
    next(err);
  }
}

/** Require a specific permission. Must run after requireAuth. */
export function requirePermission(permission: Permission) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.user) return next(Errors.unauthorized());
    if (!hasPermission(req.user.role, permission)) {
      return next(Errors.forbidden());
    }
    next();
  };
}

/** Require any of the listed roles. */
export function requireRole(...roles: RoleName[]) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.user) return next(Errors.unauthorized());
    if (!roles.includes(req.user.role)) return next(Errors.forbidden());
    next();
  };
}
