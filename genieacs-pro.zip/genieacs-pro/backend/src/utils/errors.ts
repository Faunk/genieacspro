// Typed application errors. Only `isOperational` errors expose their message
// to clients; internal errors are masked in the error handler.

export class AppError extends Error {
  public readonly statusCode: number;
  public readonly code: string;
  public readonly details?: unknown;
  public readonly isOperational: boolean;

  constructor(
    statusCode: number,
    code: string,
    message: string,
    opts?: { details?: unknown; isOperational?: boolean },
  ) {
    super(message);
    this.name = "AppError";
    this.statusCode = statusCode;
    this.code = code;
    this.details = opts?.details;
    this.isOperational = opts?.isOperational ?? true;
  }
}

export const Errors = {
  badRequest: (msg = "Permintaan tidak valid", details?: unknown) =>
    new AppError(400, "BAD_REQUEST", msg, { details }),
  validation: (msg = "Data tidak valid", details?: unknown) =>
    new AppError(422, "VALIDATION_ERROR", msg, { details }),
  unauthorized: (msg = "Tidak terautentikasi") =>
    new AppError(401, "UNAUTHORIZED", msg),
  forbidden: (msg = "Anda tidak memiliki izin untuk tindakan ini") =>
    new AppError(403, "FORBIDDEN", msg),
  notFound: (msg = "Data tidak ditemukan") => new AppError(404, "NOT_FOUND", msg),
  conflict: (msg = "Data sudah ada", details?: unknown) =>
    new AppError(409, "CONFLICT", msg, { details }),
  tooMany: (msg = "Terlalu banyak percobaan. Coba lagi nanti.") =>
    new AppError(429, "RATE_LIMITED", msg),
  // NBI-specific failures
  nbiUnreachable: (msg = "GenieACS NBI tidak dapat dijangkau") =>
    new AppError(502, "NBI_UNREACHABLE", msg),
  nbiTimeout: (msg = "GenieACS NBI tidak merespons (timeout)") =>
    new AppError(504, "NBI_TIMEOUT", msg),
  nbiHttp: (status: number, msg: string, details?: unknown) =>
    new AppError(502, "NBI_HTTP_ERROR", msg, { details, isOperational: true }),
  internal: (msg = "Terjadi kesalahan internal") =>
    new AppError(500, "INTERNAL_ERROR", msg, { isOperational: false }),
};
