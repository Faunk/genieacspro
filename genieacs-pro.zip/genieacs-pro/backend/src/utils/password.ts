import argon2 from "argon2";

/**
 * Argon2id password hashing with conservative defaults.
 * Parameters chosen to be safe on typical server hardware.
 */
const options: argon2.Options = {
  type: argon2.argon2id,
  memoryCost: 19456, // 19 MiB
  timeCost: 2,
  parallelism: 1,
};

export async function hashPassword(plain: string): Promise<string> {
  return argon2.hash(plain, options);
}

export async function verifyPassword(hash: string, plain: string): Promise<boolean> {
  try {
    return await argon2.verify(hash, plain);
  } catch {
    return false;
  }
}

/** Basic strength policy for new passwords. */
export function validatePasswordStrength(pw: string): string | null {
  if (pw.length < 10) return "Password minimal 10 karakter";
  if (!/[a-z]/.test(pw)) return "Password harus mengandung huruf kecil";
  if (!/[A-Z]/.test(pw)) return "Password harus mengandung huruf besar";
  if (!/[0-9]/.test(pw)) return "Password harus mengandung angka";
  return null;
}
