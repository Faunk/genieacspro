import pino from "pino";
import { config } from "../config/index.js";

/**
 * Structured JSON logger. Never logs cookie headers, auth headers,
 * passwords, hashes or secrets (redacted paths below).
 */
export const logger = pino({
  level: config.logLevel,
  base: { service: "genieacs-pro-backend" },
  redact: {
    paths: [
      "req.headers.cookie",
      "req.headers.authorization",
      "password",
      "newPassword",
      "*.password",
      "*.newPassword",
      "*.passwordHash",
      "*.secret",
      "body.password",
      "body.newPassword",
    ],
    remove: true,
  },
  timestamp: pino.stdTimeFunctions.isoTime,
});