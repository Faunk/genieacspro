import type { RoleName } from "../config/permissions.js";

declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        email: string;
        name: string;
        role: RoleName;
      };
      sessionId?: string;
    }
  }
}

export {};
