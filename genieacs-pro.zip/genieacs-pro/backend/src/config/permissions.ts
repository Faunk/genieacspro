// Central RBAC policy. UI and backend both consult this; backend is authoritative.
// A permission is a capability string. Roles map to allowed permissions.

export type Permission =
  | "dashboard:view"
  | "devices:view"
  | "devices:viewSensitive"
  | "devices:export"
  | "wifi:write"
  | "device:reboot"
  | "device:factoryReset"
  | "tasks:view"
  | "customers:view"
  | "customers:write"
  | "customers:export"
  | "monitoring:view"
  | "monitoring:configure"
  | "audit:view"
  | "users:view"
  | "users:manage"
  | "settings:view"
  | "settings:manage";

export type RoleName = "SUPER_ADMIN" | "OPERATOR" | "READ_ONLY";

const READ_ONLY: Permission[] = [
  "dashboard:view",
  "devices:view",
  "tasks:view",
  "customers:view",
  "monitoring:view",
  "settings:view",
];

const OPERATOR: Permission[] = [
  ...READ_ONLY,
  "devices:export",
  "wifi:write",
  "device:reboot",
  "customers:write",
  "customers:export",
];

const SUPER_ADMIN: Permission[] = [
  ...OPERATOR,
  "devices:viewSensitive",
  "device:factoryReset",
  "monitoring:configure",
  "audit:view",
  "users:view",
  "users:manage",
  "settings:manage",
];

export const ROLE_PERMISSIONS: Record<RoleName, readonly Permission[]> = {
  SUPER_ADMIN,
  OPERATOR,
  READ_ONLY,
};

export function hasPermission(role: RoleName, permission: Permission): boolean {
  return ROLE_PERMISSIONS[role].includes(permission);
}
