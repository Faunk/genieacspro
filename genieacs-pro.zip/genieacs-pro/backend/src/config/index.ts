import { z } from "zod";

/**
 * Validated application configuration.
 * Fails fast at boot if required secrets are missing or malformed.
 */
const boolish = z
  .string()
  .optional()
  .transform((v) => (v === undefined ? undefined : /^(1|true|yes|on)$/i.test(v)));

const EnvSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  APP_BASE_URL: z.string().url().default("http://localhost:5173"),
  APP_PORT: z.coerce.number().int().positive().default(8080),
  APP_TIMEZONE: z.string().default("Asia/Jakarta"),

  // GenieACS NBI. GenieACS runs on a separate host (100.30.10.2); backend dials
  // it over the network on port 7557. Never expose this port to the internet.
  GENIEACS_NBI_URL: z.string().url().default("http://100.30.10.2:7557"),
  GENIEACS_NBI_URL_INTERNAL: z.string().url().optional().or(z.literal("")),
  GENIEACS_NBI_TIMEOUT_MS: z.coerce.number().int().positive().default(10000),
  GENIEACS_NBI_CONNECTION_REQUEST: boolish,

  DEVICE_STALE_THRESHOLD_MINUTES: z.coerce.number().int().positive().default(15),
  MONITORING_POLL_SECONDS: z.coerce.number().int().positive().default(60),

  DATABASE_URL: z.string().min(1).default("postgresql://postgres:postgres@localhost:5432/genieacs_pro"),

  SESSION_SECRET: z.string().min(32).default("dev-only-insecure-secret-change-me-please-32+"),
  // NOTE: If SESSION_SECRET is present but shorter than 32 chars, validation
  // fails by design. Fix .env with: openssl rand -hex 32
  SESSION_COOKIE_NAME: z.string().default("gpro_sid"),
  SESSION_TTL_HOURS: z.coerce.number().int().positive().default(12),
  COOKIE_SECURE: boolish,
  COOKIE_SAME_SITE: z.enum(["lax", "strict", "none"]).default("lax"),

  LOGIN_RATE_WINDOW_MS: z.coerce.number().int().positive().default(900000),
  LOGIN_RATE_MAX: z.coerce.number().int().positive().default(10),

  LOG_LEVEL: z
    .enum(["fatal", "error", "warn", "info", "debug", "trace", "silent"])
    .default("info"),

  TRUST_PROXY_HOPS: z.coerce.number().int().min(0).optional(),

  BOOTSTRAP_ADMIN_EMAIL: z.string().email().optional(),
  BOOTSTRAP_ADMIN_NAME: z.string().optional(),
  BOOTSTRAP_ADMIN_PASSWORD: z.string().optional(),
});

const parsed = EnvSchema.safeParse(process.env);
if (!parsed.success) {
  const issues = parsed.error.issues
    .map((i) => `${i.path.join(".")}: ${i.message}`)
    .join("; ");
  // eslint-disable-next-line no-console
  console.error(`[config] Invalid environment: ${issues}`);
  process.exit(1);
}

const e = parsed.data;

/**
 * URL the backend process will actually dial. Prefer the explicit internal
 * override (e.g. when NBI is on a different interface) when set; otherwise
 * use the configured NBI URL as-is.
 */
export const nbiEffectiveUrl =
  e.GENIEACS_NBI_URL_INTERNAL && e.GENIEACS_NBI_URL_INTERNAL.length > 0
    ? e.GENIEACS_NBI_URL_INTERNAL
    : e.GENIEACS_NBI_URL;

export const config = {
  env: e.NODE_ENV,
  isProd: e.NODE_ENV === "production",
  isTest: e.NODE_ENV === "test",
  baseUrl: e.APP_BASE_URL,
  port: e.APP_PORT,
  timezone: e.APP_TIMEZONE,

  nbi: {
    url: e.GENIEACS_NBI_URL,
    effectiveUrl: nbiEffectiveUrl,
    timeoutMs: e.GENIEACS_NBI_TIMEOUT_MS,
    connectionRequest: e.GENIEACS_NBI_CONNECTION_REQUEST ?? true,
  },

  device: {
    staleThresholdMinutes: e.DEVICE_STALE_THRESHOLD_MINUTES,
  },
  monitoring: {
    pollSeconds: e.MONITORING_POLL_SECONDS,
  },

  session: {
    secret: e.SESSION_SECRET,
    cookieName: e.SESSION_COOKIE_NAME,
    ttlHours: e.SESSION_TTL_HOURS,
    secure: e.COOKIE_SECURE ?? e.NODE_ENV === "production",
    sameSite: e.COOKIE_SAME_SITE,
  },

  rateLimit: {
    loginWindowMs: e.LOGIN_RATE_WINDOW_MS,
    loginMax: e.LOGIN_RATE_MAX,
  },

  logLevel: e.LOG_LEVEL,
  trustProxyHops: e.TRUST_PROXY_HOPS,

  bootstrap: {
    email: e.BOOTSTRAP_ADMIN_EMAIL,
    name: e.BOOTSTRAP_ADMIN_NAME,
    password: e.BOOTSTRAP_ADMIN_PASSWORD,
  },
} as const;

export type AppConfig = typeof config;
