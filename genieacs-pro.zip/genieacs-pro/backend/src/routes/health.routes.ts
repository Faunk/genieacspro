import { Router } from "express";
import { checkDatabase } from "../database/prisma.js";
import { probeNbi } from "../services/genieacs.service.js";
import { config } from "../config/index.js";
import { logger } from "../utils/logger.js";

export const healthRouter = Router();

/** Liveness: is the backend process up? No secrets exposed. */
healthRouter.get("/", (_req, res) => {
  res.json({ status: "ok", service: "genieacs-pro-backend", time: new Date().toISOString() });
});

/** Readiness + dependency status. */
healthRouter.get("/status", async (_req, res) => {
  const started = Date.now();

  const dbPromise = checkDatabase()
    .then((r) => ({ ok: r.ok, latencyMs: r.latencyMs }))
    .catch((err) => {
      logger.error({ err }, "db health check failed");
      return { ok: false, latencyMs: null as number | null };
    });

  const nbiPromise = probeNbi();

  const [db, nbi] = await Promise.all([dbPromise, nbiPromise]);

  res.json({
    backend: { ok: true, uptimeMs: Math.round(process.uptime() * 1000) },
    database: db,
    nbi: {
      ok: nbi.ok,
      latencyMs: nbi.latencyMs,
      checkedAt: nbi.checkedAt,
      error: nbi.error ?? null,
      urlHost: safeHost(config.nbi.effectiveUrl),
    },
    version: process.env.npm_package_version ?? "0.1.0",
    checkedAt: new Date().toISOString(),
    totalMs: Date.now() - started,
  });
});

function safeHost(url: string): string {
  try {
    const u = new URL(url);
    return `${u.protocol}//${u.host}`;
  } catch {
    return "invalid-url";
  }
}
