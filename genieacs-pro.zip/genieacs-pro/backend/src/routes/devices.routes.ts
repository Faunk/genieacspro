import { Router } from "express";
import { z } from "zod";
import { requireAuth, requirePermission } from "../middleware/auth.js";
import { hasPermission } from "../config/permissions.js";
import {
  listDevices,
  getDevice,
  flattenParameters,
  DEVICE_LIST_PROJECTION,
  detectDataModel,
  getParam,
  createDeviceTask,
} from "../services/genieacs.service.js";
import { Errors } from "../utils/errors.js";
import { config } from "../config/index.js";

export const devicesRouter = Router();
devicesRouter.use(requireAuth);

const listQuerySchema = z.object({
  q: z.string().optional(),
  manufacturer: z.string().optional(),
  model: z.string().optional(),
  productClass: z.string().optional(),
  status: z.enum(["recently_informing", "stale", "unknown"]).optional(),
  // Drill-down filters used by dashboard chart clicks
  rx: z.enum(["good", "warning", "critical", "unknown"]).optional(),
  access: z.enum(["gpon", "epon", "ethernet"]).optional(),
  brand: z.string().optional(),
  temp: z.enum(["adem", "anget", "puanass", "awas"]).optional(),
  reg: z.enum(["today", "under7d", "under30d", "over30d"]).optional(),
  // Status sub-filter: 'on' or 'off' with optional age buckets
  offAge: z.enum(["any", "24h", "3d", "7d", "30d"]).optional(),
  limit: z.coerce.number().int().min(1).max(1000).default(25),
  skip: z.coerce.number().int().min(0).default(0),
  order: z.enum(["asc", "desc"]).default("desc"),
});

type DeviceFilter = z.infer<typeof listQuerySchema>;

/** Build a GenieACS query object from user filters (valid NBI syntax). */
function buildDeviceQuery(f: DeviceFilter): Record<string, unknown> | undefined {
  const and: Record<string, unknown>[] = [];
  if (f.manufacturer) {
    and.push({
      $or: [
        { "InternetGatewayDevice.DeviceInfo.Manufacturer._value": f.manufacturer },
        { "Device.DeviceInfo.Manufacturer._value": f.manufacturer },
      ],
    });
  }
  if (f.model) {
    and.push({
      $or: [
        { "InternetGatewayDevice.DeviceInfo.ModelName._value": f.model },
        { "Device.DeviceInfo.ModelName._value": f.model },
      ],
    });
  }
  if (f.productClass) and.push({ "_deviceId._ProductClass": f.productClass });
  if (f.q) {
    // Search across serial number AND PPPoE username. GenieACS can regex-match
    // the virtual parameter directly; raw WAN usernames are covered by the
    // post-filter in the list handler below.
    and.push({
      $or: [
        { "_deviceId._SerialNumber": { $regex: f.q } },
        { "VirtualParameters.pppoeUsername._value": { $regex: f.q } },
        { "VirtualParameters.pppUsername._value": { $regex: f.q } },
      ],
    });
  }
  if (f.status === "stale") {
    const cutoff = new Date(Date.now() - config.device.staleThresholdMinutes * 60_000);
    and.push({ _lastInform: { $lt: { $date: cutoff.toISOString() } } });
  } else if (f.status === "recently_informing") {
    const cutoff = new Date(Date.now() - config.device.staleThresholdMinutes * 60_000);
    and.push({ _lastInform: { $gte: { $date: cutoff.toISOString() } } });
  }
  if (and.length === 0) return undefined;
  return and.length === 1 ? and[0] : { $and: and };
}

export function computeStatus(
  lastInform: string | undefined,
): "recently_informing" | "stale" | "unknown" {
  if (!lastInform) return "unknown";
  const t = new Date(lastInform).getTime();
  if (Number.isNaN(t)) return "unknown";
  const ageMin = (Date.now() - t) / 60_000;
  return ageMin <= config.device.staleThresholdMinutes ? "recently_informing" : "stale";
}

function convertRxRawToDbm(rawNum: number): string | null {
  if (Number.isNaN(rawNum)) return null;
  // Formula from official GenieACS virtual parameter script:
  if (rawNum < 0 && rawNum > -50) {
    return rawNum.toFixed(2);
  } else if (rawNum <= -50) {
    return (rawNum / 100).toFixed(2);
  } else if (rawNum > 0) {
    const dbm = 30 + Math.log10(rawNum * 1e-7) * 10;
    if (Number.isFinite(dbm)) {
      return (Math.round(dbm * 100) / 100).toFixed(2);
    }
  }
  return null;
}

function findRxValueInObject(obj: unknown): number | null {
  if (!obj || typeof obj !== "object") return null;

  // Known vendor patterns from server script:
  // X_ZTE-COM_WANPONInterfaceConfig, X_CT-COM_EponInterfaceConfig, X_CT-COM_GponInterfaceConfig,
  // X_GponInterafceConfig, X_FH_GponInterfaceConfig, X_CMCC_EponInterfaceConfig,
  // X_CMCC_GponInterfaceConfig, X_CU_WANEPONInterfaceConfig.OpticalTransceiver
  const targetRegex = /^(X_ZTE-COM_WANPONInterfaceConfig|X_CT-COM_EponIntera?fceConfig|X_CT-COM_GponIntera?fceConfig|X_GponIntera?fceConfig|X_FH_GponInterfaceConfig|X_CMCC_EponInterfaceConfig|X_CMCC_GponInterfaceConfig|OpticalTransceiver|Interface)$/i;

  for (const [key, val] of Object.entries(obj as Record<string, any>)) {
    if (key === "RXPower" || key === "RxPower") {
      const v = val?._value ?? val;
      if (v !== undefined && v !== null && v !== "") {
        const parsed = parseFloat(String(v));
        if (!Number.isNaN(parsed)) return parsed;
      }
    }
    if (typeof val === "object" && val !== null) {
      const nested = findRxValueInObject(val);
      if (nested !== null) return nested;
    }
  }
  return null;
}

export function extractRxPower(d: Record<string, unknown>): { raw: string | null; formatted: string | null; quality: "good" | "warning" | "critical" | "unknown" } {
  // 1. First priority: Check if GenieACS VirtualParameter RXPower already calculated
  const vpRx = (d["VirtualParameters"] as any)?.RXPower?._value;
  if (vpRx !== undefined && vpRx !== null && vpRx !== "" && vpRx !== "N/A") {
    const vpNum = parseFloat(String(vpRx));
    if (!Number.isNaN(vpNum)) {
      const formatted = `${vpNum.toFixed(2)} dBm`;
      let quality: "good" | "warning" | "critical" = "good";
      if (vpNum < -27 || vpNum > -8) quality = "critical";
      else if (vpNum < -24) quality = "warning";
      return { raw: String(vpRx), formatted, quality };
    }
  }

  // 2. Second priority: Search in WANDevice / Device.Optical trees using vendor regex
  const wan = (d["InternetGatewayDevice"] as any)?.WANDevice ?? (d["Device"] as any)?.Optical;
  const rawNum = findRxValueInObject(wan);

  if (rawNum !== null) {
    const dbmStr = convertRxRawToDbm(rawNum);
    if (dbmStr !== null) {
      const dbm = parseFloat(dbmStr);
      const formatted = `${dbmStr} dBm`;
      let quality: "good" | "warning" | "critical" = "good";
      if (dbm < -27 || dbm > -8) quality = "critical";
      else if (dbm < -24) quality = "warning";
      return { raw: String(rawNum), formatted, quality };
    }
  }

  return { raw: null, formatted: null, quality: "unknown" };
}

function extractPppoeUsername(d: Record<string, unknown>): string | null {
  // 1. Prefer GenieACS virtual parameter (already computed server-side).
  const vp = (d["VirtualParameters"] as any) ?? {};
  const vpUser = vp.pppoeUsername?._value ?? vp.pppUsername?._value;
  if (vpUser != null && String(vpUser).trim() !== "") return String(vpUser);

  // 2. Fall back to walking the WAN PPP tree (TR-098 or TR-181).
  const root =
    (d["InternetGatewayDevice"] as any)?.WANDevice ?? (d["Device"] as any)?.PPP;
  if (!root) return null;

  let found: string | null = null;
  const walk = (node: any): void => {
    if (found || !node || typeof node !== "object") return;
    for (const [key, val] of Object.entries(node)) {
      if (key === "Username") {
        const v = (val as any)?._value ?? val;
        if (v != null && String(v).trim() !== "") {
          found = String(v);
          return;
        }
      }
      if (val && typeof val === "object") walk(val);
    }
  };
  walk(root);
  return found;
}

function mapDeviceRow(d: Record<string, unknown>) {
  const di = (d["InternetGatewayDevice"] as any)?.DeviceInfo ?? (d["Device"] as any)?.DeviceInfo ?? {};
  const deviceId = d["_deviceId"] as Record<string, string> | undefined;
  const get = (k: string): string | null => {
    const v = di?.[k]?._value ?? deviceId?.[`_${k}`];
    return v == null ? null : String(v);
  };
  const lastInform = (d["_lastInform"] as string | undefined) ?? undefined;
  const productClass = deviceId?.["_ProductClass"] ?? get("ProductClass");
  const rxPower = extractRxPower(d);

  return {
    id: d["_id"] as string,
    serialNumber: deviceId?.["_SerialNumber"] ?? get("SerialNumber"),
    manufacturer: deviceId?.["_Manufacturer"] ?? get("Manufacturer"),
    // Many ONTs leave ModelName empty; fall back to ProductClass for display.
    model: get("ModelName") ?? productClass,
    productClass,
    hardwareVersion: get("HardwareVersion"),
    softwareVersion: get("SoftwareVersion"),
    rxPower,
    pppoeUsername: extractPppoeUsername(d),
    lastInform: lastInform ?? null,
    status: computeStatus(lastInform),
    dataModel: detectDataModel(d as never),
  };
}

devicesRouter.get("/", requirePermission("devices:view"), async (req, res, next) => {
  try {
    const parsed = listQuerySchema.safeParse(req.query);
    if (!parsed.success) throw Errors.validation("Filter tidak valid", parsed.error.flatten());
    const f = parsed.data;
    const hasDrillFilter = !!(f.rx || f.access || f.brand || f.temp || f.reg || f.offAge);
    // When a text query or drill-down filter is present, over-fetch from NBI
    // so the client-side post-filter doesn't starve results.
    const needsOverFetch = !!f.q || hasDrillFilter;
    const overFetch = needsOverFetch ? Math.min(Math.max(f.limit * 6, 200), 1500) : f.limit;
    const devices = await listDevices({
      query: buildDeviceQuery(f),
      projection: DEVICE_LIST_PROJECTION,
      limit: overFetch,
      skip: f.q ? 0 : f.skip,
      // Saat memfilter offline (stale), urutkan ascending agar yang paling
      // lama tidak inform muncul paling atas (paling kritis dulu).
      sort: { lastInform: f.status === "stale" ? 1 : f.order === "desc" ? -1 : 1 },
    });
    let rows = devices.map(mapDeviceRow);
    if (f.q) {
      const needle = f.q.toLowerCase();
      const matched = rows.filter((r) => {
        const hay = [r.serialNumber, r.pppoeUsername, r.manufacturer, r.model, r.productClass]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();
        return hay.includes(needle);
      });
      rows = (matched.length > 0 ? matched : rows);
    }

    // ---- Drill-down filters (from dashboard chart clicks) ----
    const now = Date.now();
    const detectAccess = (d: Record<string, unknown>): "gpon" | "epon" | "ethernet" => {
      const str = JSON.stringify(d).toLowerCase();
      if (str.includes("gpon")) return "gpon";
      if (str.includes("epon")) return "epon";
      return "ethernet";
    };
    const detectTempBucket = (d: Record<string, unknown>): "adem" | "anget" | "puanass" | "awas" => {
      const di = (d["InternetGatewayDevice"] as any)?.DeviceInfo ?? (d["Device"] as any)?.DeviceInfo ?? {};
      const rawTemp = di?.TemperatureStatus?.TransceiverTemperature?._value ?? di?.Temperature?._value ?? di?.TransceiverTemperature?._value;
      let t: number | null = rawTemp != null && rawTemp !== "" ? parseFloat(String(rawTemp)) : null;
      if (t != null && t > 1000) t = t > 5000 ? Math.round(t / 256) : Math.round(t / 100);
      if (t == null || t <= 0) return "anget";
      if (t < 45) return "adem";
      if (t <= 65) return "anget";
      if (t <= 70) return "puanass";
      return "awas";
    };

    if (f.rx) {
      rows = rows.filter((r) => r.rxPower.quality === (f.rx === "critical" ? "critical" : f.rx));
    }
    if (f.access) {
      rows = rows.filter((r) => {
        const doc = devices.find((d) => (d._id as string) === (r.id as string));
        return doc ? detectAccess(doc as Record<string, unknown>) === f.access : false;
      });
    }
    if (f.brand) {
      const target = f.brand.toLowerCase();
      rows = rows.filter((r) => {
        const m = (r.manufacturer ?? "Other").toLowerCase();
        if (target === "other") {
          return !["huawei", "fiberhome", "totolink", "zte", "mikrotik"].some((b) => m.includes(b));
        }
        return m.includes(target);
      });
    }
    if (f.temp) {
      rows = rows.filter((r) => {
        const doc = devices.find((d) => (d._id as string) === (r.id as string));
        return doc ? detectTempBucket(doc as Record<string, unknown>) === f.temp : false;
      });
    }
    if (f.reg) {
      rows = rows.filter((r) => {
        const doc = devices.find((d) => (d._id as string) === (r.id as string));
        const reg = (doc as any)?._registered ?? doc?._lastInform;
        const ts = reg ? new Date(String(reg)).getTime() : now;
        const ageDays = (now - ts) / (1000 * 60 * 60 * 24);
        if (f.reg === "today") return ageDays < 1;
        if (f.reg === "under7d") return ageDays <= 7;
        if (f.reg === "under30d") return ageDays > 7 && ageDays <= 30;
        return ageDays > 30;
      });
    }
    if (f.offAge) {
      rows = rows.filter((r) => {
        if (r.status === "recently_informing") return false;
        if (f.offAge === "any") return true;
        const li = r.lastInform ? new Date(r.lastInform).getTime() : 0;
        const hours = (now - li) / (1000 * 60 * 60);
        const days = hours / 24;
        if (f.offAge === "24h") return hours > 24;
        if (f.offAge === "3d") return days > 3;
        if (f.offAge === "7d") return days > 7;
        return days > 30;
      });
    }

    rows = rows.slice(f.skip, f.skip + f.limit);

    res.json({
      data: rows,
      page: { limit: f.limit, skip: f.skip, returned: rows.length },
    });
  } catch (err) {
    next(err);
  }
});

devicesRouter.get("/:id", requirePermission("devices:view"), async (req, res, next) => {
  try {
    // Express already URL-decodes route params; do NOT decode again (avoids
    // mangling ids that contain %2D / literal '-' in the original _id).
    const doc = await getDevice(req.params.id ?? "");
    res.json({
      data: {
        id: doc._id,
        dataModel: detectDataModel(doc),
        lastInform: doc._lastInform ?? null,
        status: computeStatus(doc._lastInform),
        document: doc,
      },
    });
  } catch (err) {
    next(err);
  }
});

const SENSITIVE = /password|passphrase|secret|token|credential|psk|preSharedKey/i;

function formatUptime(secondsStr: string | undefined | null): string {
  if (!secondsStr) return "—";
  const sec = parseInt(secondsStr, 10);
  if (Number.isNaN(sec)) return secondsStr;
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return `${d}d ${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function formatTemperature(raw: string | undefined | null): string {
  if (!raw) return "—";
  const num = parseFloat(raw);
  if (Number.isNaN(num)) return raw;
  // Vendor scales: if raw > 1000, scale down (either / 256 or / 100)
  let c = num;
  if (num > 1000) {
    c = num > 5000 ? Math.round(num / 256) : Math.round(num / 100);
  }
  return `${c} °C`;
}

devicesRouter.get("/:id/summary", requirePermission("devices:view"), async (req, res, next) => {
  try {
    const doc = await getDevice(req.params.id ?? "");
    const model = detectDataModel(doc);
    const prefix = model === "TR-181" ? "Device" : "InternetGatewayDevice";
    
    const params = flattenParameters(doc);
    const findParam = (regex: RegExp): string | null => {
      const p = params.find((it) => regex.test(it.path));
      return p && p.value != null ? String(p.value) : null;
    };

    const pppUser = findParam(/WANPPPConnection\.\d+\.Username$/i) ?? findParam(/VirtualParameters\.ppp.*Username/i);
    const pppIP = findParam(/WANPPPConnection\.\d+\.ExternalIPAddress$/i) ?? findParam(/VirtualParameters\.pppoeIP/i);
    const macAddr = findParam(/WANPPPConnection\.\d+\.MACAddress$/i) ?? findParam(/VirtualParameters\.MacAddress/i) ?? findParam(/WANDevice.*MACAddress/i);
    const routerIP = findParam(/LANHostConfigManagement\.IPInterface\.\d+\.IPInterfaceIPAddress$/i) ?? "192.168.1.1";
    const ssid = findParam(/WLANConfiguration\.\d+\.SSID$/i) ?? findParam(/VirtualParameters\.WlanSSID/i);
    const wifiPass = findParam(/WLANConfiguration\.\d+\.(KeyPassphrase|PreSharedKey\.\d+\.PreSharedKey)$/i);
    const wifiActiveCount = findParam(/WLANConfiguration\.\d+\.TotalAssociations$/i) ?? "1";
    const tempRaw = findParam(/TransceiverTemperature$/i) ?? findParam(/Temperature$/i);
    const rxPower = extractRxPower(doc);

    const di = (doc as any)["InternetGatewayDevice"]?.DeviceInfo ?? (doc as any)["Device"]?.DeviceInfo ?? {};
    const devId = doc._deviceId;

    // Check pppoe password from VirtualParameters or raw param
    const pppPass = findParam(/WANPPPConnection\.\d+\.Password$/i) ?? findParam(/VirtualParameters\.pppoePassword/i) ?? "";

    res.json({
      data: {
        id: doc._id,
        dataModel: model,
        pppoePassword: pppPass,
        serialNumber: devId?._SerialNumber ?? getParam(doc, `${prefix}.DeviceInfo.SerialNumber`) ?? null,
        productClass: devId?._ProductClass ?? getParam(doc, `${prefix}.DeviceInfo.ProductClass`) ?? null,
        manufacturer: devId?._Manufacturer ?? getParam(doc, `${prefix}.DeviceInfo.Manufacturer`) ?? null,
        hardwareVersion: getParam(doc, `${prefix}.DeviceInfo.HardwareVersion`) ?? null,
        softwareVersion: getParam(doc, `${prefix}.DeviceInfo.SoftwareVersion`) ?? null,
        macAddress: macAddr,
        rxPower: rxPower.formatted ?? "—",
        rxQuality: rxPower.quality,
        temperature: formatTemperature(tempRaw),
        uptime: formatUptime(getParam(doc, `${prefix}.DeviceInfo.UpTime`)),
        pppoeUsername: pppUser ?? "—",
        wanIP: pppIP ?? "—",
        routerIP,
        wifiSSID: ssid ?? "—",
        wifiPassword: wifiPass ? wifiPass : "(blank / tidak diset)",
        wifiActiveUsers: wifiActiveCount,
        lastInform: doc._lastInform ?? null,
        status: computeStatus(doc._lastInform),
      },
    });
  } catch (err) {
    next(err);
  }
});

devicesRouter.get("/:id/wan", requirePermission("devices:view"), async (req, res, next) => {
  try {
    const doc = await getDevice(req.params.id ?? "");
    const params = flattenParameters(doc);

    // Scan for WANPPPConnection instances
    const connections: Array<{
      index: string;
      name: string;
      type: string;
      serviceList: string;
      status: string;
      username: string;
      password: string;
      ipAddress: string;
      macAddress: string;
      vlanId: string;
      uptime: string;
    }> = [];

    // Group by connection instance path
    const pppPaths = params.filter((p) => /WANPPPConnection\.\d+\./i.test(p.path));
    const instanceRegex = /(InternetGatewayDevice\.WANDevice\.\d+\.WANConnectionDevice\.\d+\.WANPPPConnection\.(\d+))/i;
    const instances = new Set<string>();

    for (const p of pppPaths) {
      const m = p.path.match(instanceRegex);
      if (m && m[1]) instances.add(m[1]);
    }

    for (const inst of instances) {
      const findVal = (key: string): string => {
        const item = params.find((it) => it.path.toLowerCase() === `${inst}.${key}`.toLowerCase());
        return item && item.value != null ? String(item.value) : "";
      };

      const name = findVal("Name") || `PPPoE Connection`;
      const username = findVal("Username") || ((doc as any)["VirtualParameters"]?.pppoeUsername?._value ?? "");
      const password = findVal("Password") || ((doc as any)["VirtualParameters"]?.pppoePassword?._value ?? "");
      const status = findVal("ConnectionStatus") || "Disconnected";
      const ipAddress = findVal("ExternalIPAddress");
      const macAddress = findVal("MACAddress") || ((doc as any)["VirtualParameters"]?.MacAddress?._value ?? "");
      const serviceList = findVal("X_CT-COM_ServiceList") || findVal("ServiceList") || "INTERNET";
      const uptimeSec = findVal("Uptime");
      
      // Extract VLAN ID from Name if available (e.g. VID_601) or from parent link config
      let vlanId = "—";
      const vidMatch = name.match(/VID_(\d+)/i) || name.match(/VLAN_?(\d+)/i);
      if (vidMatch && vidMatch[1]) {
        vlanId = vidMatch[1];
      } else {
        // Try checking parent WANEponLinkConfig or WANEthernetLinkConfig
        const parentPath = inst.replace(/\.WANPPPConnection\.\d+$/i, "");
        const vlanParam = params.find((it) => it.path.startsWith(parentPath) && /VLANIDMark/i.test(it.path));
        if (vlanParam && vlanParam.value) vlanId = String(vlanParam.value);
      }

      connections.push({
        index: inst.split(".").pop() || "1",
        name,
        type: "PPPoE",
        serviceList,
        status,
        username,
        password,
        ipAddress,
        macAddress,
        vlanId,
        uptime: formatUptime(uptimeSec),
      });
    }

    // Fallback if no specific instance found but VirtualParameters exist
    if (connections.length === 0) {
      const vp = (doc as any)["VirtualParameters"] ?? {};
      connections.push({
        index: "1",
        name: "PPPoE Default",
        type: "PPPoE",
        serviceList: "INTERNET",
        status: "Connected",
        username: vp.pppoeUsername?._value ?? vp.pppUsername?._value ?? "—",
        password: vp.pppoePassword?._value ?? "—",
        ipAddress: vp.pppoeIP?._value ?? "—",
        macAddress: vp.pppoeMac?._value ?? vp.MacAddress?._value ?? "—",
        vlanId: "—",
        uptime: "—",
      });
    }

    res.json({ data: connections });
  } catch (err) {
    next(err);
  }
});

devicesRouter.get("/:id/parameters", requirePermission("devices:view"), async (req, res, next) => {
  try {
    const doc = await getDevice(req.params.id ?? "");
    const canSeeSensitive = hasPermission(req.user!.role, "devices:viewSensitive");
    const filterPath = typeof req.query.path === "string" ? req.query.path : undefined;

    let params = flattenParameters(doc);
    if (filterPath) params = params.filter((p) => p.path.includes(filterPath));

    const data = params.map((p) => ({
      ...p,
      value: SENSITIVE.test(p.path) && !canSeeSensitive ? "[REDACTED]" : p.value,
    }));

    res.json({ data, count: data.length, dataModel: detectDataModel(doc) });
  } catch (err) {
    next(err);
  }
});

/* --------------------------- WLAN tab --------------------------- */
devicesRouter.get("/:id/wlan", requirePermission("devices:view"), async (req, res, next) => {
  try {
    const doc = await getDevice(req.params.id ?? "");
    const params = flattenParameters(doc);
    const canSeeSensitive = hasPermission(req.user!.role, "devices:viewSensitive");

    const instances = new Set<string>();
    for (const p of params) {
      const m = p.path.match(/(InternetGatewayDevice\.LANDevice\.\d+\.WLANConfiguration\.(\d+))/i);
      if (m && m[1]) instances.add(m[1]);
    }

    const ssids: Array<{
      index: string;
      path: string;
      ssid: string;
      enabled: string;
      band: string;
      security: string;
      password: string;
      channel: string;
      totalAssociations: string;
      beaconType: string;
    }> = [];

    for (const inst of instances) {
      const idx = inst.split(".").pop() || "1";
      const find = (suffix: string): string => {
        const it = params.find((p) => p.path.toLowerCase() === `${inst}.${suffix}`.toLowerCase());
        return it && it.value != null ? String(it.value) : "";
      };
      const password =
        find("KeyPassphrase") ||
        find("PreSharedKey.1.KeyPassphrase") ||
        find("PreSharedKey.1.PreSharedKey");
      ssids.push({
        index: idx,
        path: inst,
        ssid: find("SSID") || "—",
        enabled: find("Enable") || "1",
        band: idx === "1" ? "2.4 GHz" : idx === "2" ? "5 GHz" : `Radio ${idx}`,
        security: find("BeaconType") || find("IEEE11iAuthenticationMode") || "—",
        password: password ? (canSeeSensitive ? password : "[REDACTED]") : "(blank / tidak diset)",
        channel: find("Channel") || "Auto",
        totalAssociations: find("TotalAssociations") || "0",
        beaconType: find("BeaconType") || "",
      });
    }

    res.json({ data: ssids, count: ssids.length });
  } catch (err) {
    next(err);
  }
});

const wlanUpdateSchema = z.object({
  index: z.string().min(1),
  ssid: z.string().optional(),
  password: z.string().min(8).max(63).optional(),
  enabled: z.boolean().optional(),
});

devicesRouter.post("/:id/wlan", requirePermission("wifi:write"), async (req, res, next) => {
  try {
    const parsed = wlanUpdateSchema.safeParse(req.body);
    if (!parsed.success) throw Errors.validation("Payload tidak valid", parsed.error.flatten());
    const u = parsed.data;
    const deviceId = req.params.id ?? "";
    const doc = await getDevice(deviceId);
    const model = detectDataModel(doc);
    if (model !== "TR-098") {
      throw Errors.badRequest("Edit WLAN via NBI hanya didukung untuk data model TR-098 saat ini");
    }

    const values: Array<[string, string, string]> = [];
    const basePath = `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${u.index}`;

    if (u.ssid !== undefined && u.ssid.trim() !== "") {
      values.push([`${basePath}.SSID`, u.ssid.trim(), "xsd:string"]);
    }
    if (u.password !== undefined && u.password !== "") {
      const params = flattenParameters(doc);
      // Prefer KeyPassphrase; fallback to PreSharedKey variant
      const hasKeyPassphrase = params.some((p) => p.path.toLowerCase() === `${basePath}.KeyPassphrase`.toLowerCase());
      if (hasKeyPassphrase) {
        values.push([`${basePath}.KeyPassphrase`, u.password, "xsd:string"]);
      } else {
        values.push([`${basePath}.PreSharedKey.1.KeyPassphrase`, u.password, "xsd:string"]);
        values.push([`${basePath}.PreSharedKey.1.PreSharedKey`, u.password, "xsd:string"]);
      }
    }
    if (u.enabled !== undefined) {
      values.push([`${basePath}.Enable`, u.enabled ? "1" : "0", "xsd:boolean"]);
    }

    if (values.length === 0) {
      throw Errors.badRequest("Tidak ada perubahan yang dikirim");
    }

    await createDeviceTask(deviceId, {
      name: "setParameterValues",
      parameterValues: values,
    });

    res.json({ data: { ok: true, queued: values.length } });
  } catch (err) {
    next(err);
  }
});

/* --------------------------- LAN tab ---------------------------- */
devicesRouter.get("/:id/lan", requirePermission("devices:view"), async (req, res, next) => {
  try {
    const doc = await getDevice(req.params.id ?? "");
    const params = flattenParameters(doc);

    const find = (re: RegExp): string | null => {
      const p = params.find((it) => re.test(it.path));
      return p && p.value != null ? String(p.value) : null;
    };

    // LAN interface properties (TR-098 default; TR-181 variants lookup)
    const lanIP = find(/LANHostConfigManagement\.IPInterface\.\d+\.IPInterfaceIPAddress$/i) ??
      find(/Device\.IP\.Interface\.\d+\.IPv4Address\.\d+\.IPAddress$/i) ?? "—";
    const subnet = find(/LANHostConfigManagement\.IPInterface\.\d+\.SubnetMask$/i) ??
      find(/Device\.IP\.Interface\.\d+\.IPv4Address\.\d+\.SubnetMask$/i) ?? "—";
    const dhcpEnabled = find(/LANHostConfigManagement\.DHCPServerEnable$/i) ??
      find(/Device\.DHCPv4\.Server\.Enable$/i) ?? "—";
    const dhcpMin = find(/LANHostConfigManagement\.MinAddress$/i) ??
      find(/DHCPv4\.Server\.Pool\.\d+\.MinAddress$/i) ?? "—";
    const dhcpMax = find(/LANHostConfigManagement\.MaxAddress$/i) ??
      find(/DHCPv4\.Server\.Pool\.\d+\.MaxAddress$/i) ?? "—";
    const dns = find(/LANHostConfigManagement\.DNSServers$/i) ??
      find(/DomainNameServer$/i) ?? "—";
    const domain = find(/LANHostConfigManagement\.DomainName$/i) ??
      find(/DHCPv4\.Server\.DomainName$/i) ?? "—";
    const macAddr = find(/LANDevice\.\d+\.LANHostConfigManagement\.MACAddress$/i) ??
      find(/LANDevice\.\d+\.LANEthernetInterfaceConfig\.\d+\.MACAddress$/i) ?? "—";

    // LAN port states (LAN Ethernet interface status)
    const portStatus: Array<{ index: string; enabled: string; status: string; mac: string; bytesSent?: string; bytesReceived?: string }> = [];
    for (const p of params) {
      const m = p.path.match(/LANEthernetInterfaceConfig\.(\d+)\.Status$/i);
      if (m && m[1]) {
        const idx = m[1];
        const base = `InternetGatewayDevice.LANDevice.1.LANEthernetInterfaceConfig.${idx}`;
        const mac = params.find((it) => it.path === `${base}.MACAddress`);
        const en = params.find((it) => it.path === `${base}.Enable`);
        const bs = params.find((it) => it.path === `${base}.Stats.BytesSent`);
        const br = params.find((it) => it.path === `${base}.Stats.BytesReceived`);
        portStatus.push({
          index: idx,
          enabled: en?.value != null ? String(en.value) : "0",
          status: p.value != null ? String(p.value) : "Down",
          mac: mac?.value != null ? String(mac.value) : "—",
          bytesSent: bs?.value != null ? String(bs.value) : undefined,
          bytesReceived: br?.value != null ? String(br.value) : undefined,
        });
      }
    }

    // DHCP leases
    const leases: Array<{ hostname: string; ip: string; mac: string; expires: string }> = [];
    for (const p of params) {
      const m = p.path.match(/LANHostConfigManagement\.IPInterface\.\d+\.DHCPLease\.(\d+)/i) ||
        p.path.match(/LANDevice\.\d+\.Hosts\.Host\.(\d+)/i);
      if (m && m[1] && /Active$/i.test(p.path)) {
        const idx = m[1];
        const base = p.path.replace(/\.Active$/i, "");
        const hostName = params.find((it) => it.path === `${base}.HostName`);
        const ip = params.find((it) => it.path === `${base}.IPAddress`);
        const mac = params.find((it) => it.path === `${base}.MACAddress`);
        const lt = params.find((it) => it.path === `${base}.LeaseTimeRemaining`);
        leases.push({
          hostname: hostName?.value != null ? String(hostName.value) : "—",
          ip: ip?.value != null ? String(ip.value) : "—",
          mac: mac?.value != null ? String(mac.value) : "—",
          expires: lt?.value != null ? formatUptime(String(lt.value)) : "—",
        });
      }
    }

    res.json({
      data: {
        ip: lanIP,
        subnet,
        dhcpEnabled: String(dhcpEnabled),
        dhcpRange: dhcpMin && dhcpMax ? `${dhcpMin} - ${dhcpMax}` : "—",
        dns,
        domain,
        macAddress: macAddr,
        ports: portStatus,
        leases,
      },
    });
  } catch (err) {
    next(err);
  }
});

/* --------------------------- TR-069 tab ------------------------- */
devicesRouter.get("/:id/tr069", requirePermission("devices:view"), async (req, res, next) => {
  try {
    const doc = await getDevice(req.params.id ?? "");
    const params = flattenParameters(doc);

    const find = (re: RegExp): string | null => {
      const p = params.find((it) => re.test(it.path));
      return p && p.value != null ? String(p.value) : null;
    };

    res.json({
      data: {
        acsUrl:
          find(/ManagementServer\.URL$/i) ??
          find(/Device\.ManagementServer\.URL$/i) ?? "—",
        acsUsername:
          find(/ManagementServer\.Username$/i) ??
          find(/Device\.ManagementServer\.Username$/i) ?? "—",
        periodicInformEnabled:
          find(/ManagementServer\.PeriodicInformEnable$/i) ??
          find(/Device\.ManagementServer\.PeriodicInformEnable$/i) ?? "—",
        periodicInformInterval:
          find(/ManagementServer\.PeriodicInformInterval$/i) ??
          find(/Device\.ManagementServer\.PeriodicInformInterval$/i) ?? "—",
        periodicInformTime:
          find(/ManagementServer\.PeriodicInformTime$/i) ??
          find(/Device\.ManagementServer\.PeriodicInformTime$/i) ?? "—",
        connectionRequestUrl:
          find(/ManagementServer\.ConnectionRequestURL$/i) ??
          find(/Device\.ManagementServer\.ConnectionRequestURL$/i) ?? "—",
        connectionRequestUsername:
          find(/ManagementServer\.ConnectionRequestUsername$/i) ??
          find(/Device\.ManagementServer\.ConnectionRequestUsername$/i) ?? "—",
        parameterKey:
          find(/ManagementServer\.ParameterKey$/i) ??
          find(/Device\.ManagementServer\.ParameterKey$/i) ?? "—",
        lastInform: doc._lastInform ?? null,
        registered: (doc as any)._registered ?? null,
      },
    });
  } catch (err) {
    next(err);
  }
});

/* ------------------------- Remote Actions ----------------------- */

devicesRouter.post("/:id/reboot", requirePermission("device:reboot"), async (req, res, next) => {
  try {
    const deviceId = req.params.id ?? "";
    await createDeviceTask(deviceId, { name: "reboot" });
    res.json({ data: { ok: true, task: "reboot", queued: true } });
  } catch (err) {
    next(err);
  }
});

devicesRouter.post("/:id/summon", requirePermission("devices:view"), async (req, res, next) => {
  try {
    const deviceId = req.params.id ?? "";
    await createDeviceTask(deviceId, { name: "refreshObject", objectName: "" });
    res.json({ data: { ok: true, task: "refreshObject", queued: true } });
  } catch (err) {
    next(err);
  }
});

devicesRouter.post("/:id/factory-reset", requirePermission("device:factoryReset"), async (req, res, next) => {
  try {
    const deviceId = req.params.id ?? "";
    await createDeviceTask(deviceId, { name: "factoryReset" });
    res.json({ data: { ok: true, task: "factoryReset", queued: true } });
  } catch (err) {
    next(err);
  }
});
