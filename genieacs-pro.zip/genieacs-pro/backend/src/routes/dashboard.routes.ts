import { Router } from "express";
import { requireAuth, requirePermission } from "../middleware/auth.js";
import { listDevices, DEVICE_LIST_PROJECTION, probeNbi } from "../services/genieacs.service.js";
import { prisma } from "../database/prisma.js";
import { computeStatus, extractRxPower } from "./devices.routes.js";
import { config } from "../config/index.js";

export const dashboardRouter = Router();
dashboardRouter.use(requireAuth);

const SCAN_LIMIT = 2000;

function extractTemperatureNumber(d: any): number | null {
  const di = d?.InternetGatewayDevice?.DeviceInfo ?? d?.Device?.DeviceInfo ?? {};
  const raw = di?.TemperatureStatus?.TransceiverTemperature?._value ?? di?.Temperature?._value ?? di?.TransceiverTemperature?._value;
  if (raw == null || raw === "") return null;
  const num = parseFloat(String(raw));
  if (Number.isNaN(num)) return null;
  if (num > 1000) return num > 5000 ? Math.round(num / 256) : Math.round(num / 100);
  return Math.round(num);
}

function detectAccessType(d: any): "GPON" | "EPON" | "Ethernet/Converter" {
  const str = JSON.stringify(d).toLowerCase();
  if (str.includes("gpon")) return "GPON";
  if (str.includes("epon")) return "EPON";
  return "EPON"; // standard fallback for FTTH ONT
}

dashboardRouter.get("/stats", requirePermission("dashboard:view"), async (_req, res, next) => {
  try {
    const [devices, customerCount, linkedCount, noteCount, recentAudit] = await Promise.all([
      listDevices({
        projection: DEVICE_LIST_PROJECTION,
        limit: SCAN_LIMIT,
        sort: { lastInform: -1 },
      }),
      prisma.customer.count(),
      prisma.customer.count({ where: { deviceId: { not: null } } }),
      prisma.customer.count({ where: { technicianNotes: { not: null } } }),
      prisma.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 10 }),
    ]);

    const now = Date.now();
    const staleMs = config.device.staleThresholdMinutes * 60_000;

    let recentlyInforming = 0;
    let stale = 0;
    let unknown = 0;
    const byManufacturer = new Map<string, number>();
    const byModel = new Map<string, number>();
    const byFirmware = new Map<string, number>();
    const byDay = new Map<string, number>();

    // 1. Status Breakdown (on, off, off > 24h, off > 3d, off > 7d, off > 30d)
    const statusChart = {
      on: 0,
      off: 0,
      off24h: 0,
      off3d: 0,
      off7d: 0,
      off30d: 0,
    };

    // 2. Access Type (GPON, EPON, Ethernet/Converter)
    const accessChart = {
      gpon: 0,
      epon: 0,
      ethernet: 0,
    };

    // 3. Optical RX (Bagus, Sedang, Kritis)
    const opticalRxChart = {
      bagus: 0,
      sedang: 0,
      kritis: 0,
    };

    // 4. Merk Perangkat Breakdown
    const brandChart: Record<string, number> = {
      Huawei: 0,
      FiberHome: 0,
      TOTOLINK: 0,
      ZTE: 0,
      MikroTik: 0,
      Other: 0,
    };

    // 5. Devices Register Breakdown
    const registerChart = {
      today: 0,
      under7d: 0,
      under30d: 0,
      over30d: 0,
    };

    // 6. Optical Temperatur Breakdown
    const tempChart = {
      adem: 0,    // < 45°C
      anget: 0,   // 45 - 65°C
      puanass: 0, // > 65 - 70°C
      awas: 0,    // > 70°C
    };

    for (const d of devices) {
      const lastInform = d._lastInform;
      const status = computeStatus(lastInform);
      if (status === "recently_informing") {
        recentlyInforming++;
        statusChart.on++;
      } else if (status === "stale") {
        stale++;
        const diffMs = lastInform ? now - new Date(lastInform).getTime() : Infinity;
        const diffHours = diffMs / (1000 * 60 * 60);
        const diffDays = diffHours / 24;

        if (diffDays > 30) statusChart.off30d++;
        else if (diffDays > 7) statusChart.off7d++;
        else if (diffDays > 3) statusChart.off3d++;
        else if (diffHours > 24) statusChart.off24h++;
        else statusChart.off++;
      } else {
        unknown++;
        statusChart.off++;
      }

      // Access Type
      const acc = detectAccessType(d);
      if (acc === "GPON") accessChart.gpon++;
      else if (acc === "EPON") accessChart.epon++;
      else accessChart.ethernet++;

      // Optical RX
      const rx = extractRxPower(d as any);
      if (rx.quality === "good") opticalRxChart.bagus++;
      else if (rx.quality === "warning") opticalRxChart.sedang++;
      else opticalRxChart.kritis++; // critical or unknown

      // Manufacturer & Brand
      const di = ((d as any).InternetGatewayDevice?.DeviceInfo) ?? ((d as any).Device?.DeviceInfo) ?? {};
      const productClass = (d as any)._deviceId?._ProductClass ?? di?.ProductClass?._value;
      const rawMan = (d as any)._deviceId?._Manufacturer ?? di?.Manufacturer?._value ?? "Other";
      const manUpper = String(rawMan).toUpperCase();

      if (manUpper.includes("HUAWEI")) brandChart["Huawei"] = (brandChart["Huawei"] ?? 0) + 1;
      else if (manUpper.includes("FIBERHOME")) brandChart["FiberHome"] = (brandChart["FiberHome"] ?? 0) + 1;
      else if (manUpper.includes("TOTOLINK")) brandChart["TOTOLINK"] = (brandChart["TOTOLINK"] ?? 0) + 1;
      else if (manUpper.includes("ZTE")) brandChart["ZTE"] = (brandChart["ZTE"] ?? 0) + 1;
      else if (manUpper.includes("MIKROTIK")) brandChart["MikroTik"] = (brandChart["MikroTik"] ?? 0) + 1;
      else brandChart["Other"] = (brandChart["Other"] ?? 0) + 1;

      const model = di?.ModelName?._value ?? productClass ?? "Unknown";
      const fw = di?.SoftwareVersion?._value ?? "Unknown";
      byManufacturer.set(rawMan, (byManufacturer.get(rawMan) ?? 0) + 1);
      byModel.set(model, (byModel.get(model) ?? 0) + 1);
      byFirmware.set(fw, (byFirmware.get(fw) ?? 0) + 1);

      // Register Age
      const regDate = (d as any)._registered ? new Date((d as any)._registered).getTime() : (lastInform ? new Date(lastInform).getTime() : now);
      const regDiffDays = (now - regDate) / (1000 * 60 * 60 * 24);
      if (regDiffDays < 1) registerChart.today++;
      else if (regDiffDays <= 7) registerChart.under7d++;
      else if (regDiffDays <= 30) registerChart.under30d++;
      else registerChart.over30d++;

      // Optical Temperature
      const temp = extractTemperatureNumber(d);
      if (temp === null || temp <= 0) {
        // Default reasonable temp representation if sensor unpopulated
        tempChart.anget++;
      } else if (temp < 45) {
        tempChart.adem++;
      } else if (temp <= 65) {
        tempChart.anget++;
      } else if (temp <= 70) {
        tempChart.puanass++;
      } else {
        tempChart.awas++;
      }

      if (lastInform) {
        const day = new Date(lastInform).toISOString().slice(0, 10);
        byDay.set(day, (byDay.get(day) ?? 0) + 1);
      }
    }

    const series: { date: string; count: number }[] = [];
    for (let i = 29; i >= 0; i--) {
      const d = new Date(now - i * 86_400_000).toISOString().slice(0, 10);
      series.push({ date: d, count: byDay.get(d) ?? 0 });
    }

    const top = (m: Map<string, number>, n = 8) =>
      [...m.entries()]
        .map(([name, count]) => ({ name, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, n);

    res.json({
      data: {
        devices: {
          total: devices.length,
          scanned: devices.length,
          scanCap: SCAN_LIMIT,
          capped: devices.length >= SCAN_LIMIT,
          recentlyInforming,
          stale,
          unknown,
          staleThresholdMinutes: config.device.staleThresholdMinutes,
        },
        distributions: {
          byManufacturer: top(byManufacturer),
          byModel: top(byModel),
          byFirmware: top(byFirmware),
        },
        nocCharts: {
          status: statusChart,
          accessType: accessChart,
          opticalRx: opticalRxChart,
          brands: brandChart,
          registered: registerChart,
          temperature: tempChart,
        },
        customers: { total: customerCount, linked: linkedCount, withNotes: noteCount },
        lastInformSeries: series,
        recentActivity: recentAudit.map((a) => ({
          id: a.id,
          action: a.action,
          summary: a.summary,
          result: a.result,
          at: a.createdAt,
        })),
      },
    });
  } catch (err) {
    next(err);
  }
});

/** Connectivity summary for the dashboard sidebar. */
dashboardRouter.get("/connectivity", requirePermission("dashboard:view"), async (_req, res, next) => {
  try {
    const nbi = await probeNbi();
    res.json({
      data: {
        nbi: { ok: nbi.ok, latencyMs: nbi.latencyMs, checkedAt: nbi.checkedAt, error: nbi.error ?? null },
      },
    });
  } catch (err) {
    next(err);
  }
});
