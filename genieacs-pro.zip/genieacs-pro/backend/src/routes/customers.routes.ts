import { Router } from "express";
import { z } from "zod";
import { prisma } from "../database/prisma.js";
import { requireAuth, requirePermission } from "../middleware/auth.js";
import { Errors } from "../utils/errors.js";
import { writeAudit } from "../services/audit.service.js";
import { getDevice } from "../services/genieacs.service.js";

export const customersRouter = Router();
customersRouter.use(requireAuth);

const listSchema = z.object({
  q: z.string().optional(),
  area: z.string().optional(),
  status: z.enum(["ACTIVE", "SUSPENDED", "INACTIVE", "PENDING"]).optional(),
  limit: z.coerce.number().int().min(1).max(200).default(25),
  skip: z.coerce.number().int().min(0).default(0),
});

customersRouter.get("/", requirePermission("customers:view"), async (req, res, next) => {
  try {
    const parsed = listSchema.safeParse(req.query);
    if (!parsed.success) throw Errors.validation("Filter tidak valid", parsed.error.flatten());
    const f = parsed.data;

    const where: Record<string, unknown> = {};
    if (f.area) where.area = f.area;
    if (f.status) where.status = f.status;
    if (f.q) {
      where.OR = [
        { name: { contains: f.q, mode: "insensitive" } },
        { customerNumber: { contains: f.q, mode: "insensitive" } },
        { deviceSerial: { contains: f.q, mode: "insensitive" } },
        { address: { contains: f.q, mode: "insensitive" } },
      ];
    }

    const [rows, total] = await Promise.all([
      prisma.customer.findMany({
        where,
        orderBy: { createdAt: "desc" },
        take: f.limit,
        skip: f.skip,
      }),
      prisma.customer.count({ where }),
    ]);

    res.json({ data: rows, page: { limit: f.limit, skip: f.skip, total } });
  } catch (err) {
    next(err);
  }
});

const createSchema = z.object({
  customerNumber: z.string().min(1),
  name: z.string().min(1),
  phone: z.string().optional(),
  address: z.string().min(1),
  area: z.string().optional(),
  servicePackage: z.string().optional(),
  status: z.enum(["ACTIVE", "SUSPENDED", "INACTIVE", "PENDING"]).default("ACTIVE"),
  technicianNotes: z.string().optional(),
  installedAt: z.string().datetime().optional(),
});

customersRouter.post("/", requirePermission("customers:write"), async (req, res, next) => {
  try {
    const parsed = createSchema.safeParse(req.body);
    if (!parsed.success) throw Errors.validation("Data pelanggan tidak valid", parsed.error.flatten());
    const data = parsed.data;

    const exists = await prisma.customer.findUnique({ where: { customerNumber: data.customerNumber } });
    if (exists) throw Errors.conflict("Nomor pelanggan sudah dipakai");

    const customer = await prisma.customer.create({
      data: {
        customerNumber: data.customerNumber,
        name: data.name,
        phone: data.phone ?? null,
        address: data.address,
        area: data.area ?? null,
        servicePackage: data.servicePackage ?? null,
        status: data.status,
        technicianNotes: data.technicianNotes ?? null,
        installedAt: data.installedAt ? new Date(data.installedAt) : null,
      },
    });

    await writeAudit({
      req,
      userId: req.user?.id,
      userRole: req.user?.role,
      action: "customer.create",
      targetType: "customer",
      targetId: customer.id,
      summary: `Pelanggan dibuat: ${customer.customerNumber}`,
    });

    res.status(201).json({ data: customer });
  } catch (err) {
    next(err);
  }
});

customersRouter.get("/:id", requirePermission("customers:view"), async (req, res, next) => {
  try {
    const customer = await prisma.customer.findUnique({
      where: { id: req.params.id },
      include: { histories: { orderBy: { createdAt: "desc" }, take: 50 } },
    });
    if (!customer) throw Errors.notFound("Pelanggan tidak ditemukan");
    res.json({ data: customer });
  } catch (err) {
    next(err);
  }
});

const patchSchema = createSchema.partial();

customersRouter.patch("/:id", requirePermission("customers:write"), async (req, res, next) => {
  try {
    const parsed = patchSchema.safeParse(req.body);
    if (!parsed.success) throw Errors.validation("Data tidak valid", parsed.error.flatten());

    const existing = await prisma.customer.findUnique({ where: { id: req.params.id } });
    if (!existing) throw Errors.notFound("Pelanggan tidak ditemukan");

    const updates: Record<string, unknown> = { ...parsed.data };
    if (updates.installedAt) updates.installedAt = new Date(updates.installedAt as string);

    // Record change history for changed fields.
    const history = Object.entries(parsed.data)
      .filter(([k, v]) => (existing as Record<string, unknown>)[k] !== v)
      .map(([field, newValue]) => ({
        customerId: existing.id,
        changedBy: req.user?.id ?? null,
        field,
        oldValue: existing[field as keyof typeof existing] != null ? String(existing[field as keyof typeof existing]) : null,
        newValue: newValue != null ? String(newValue) : null,
      }));

    const customer = await prisma.$transaction(async (tx) => {
      const updated = await tx.customer.update({ where: { id: req.params.id }, data: updates });
      if (history.length > 0) await tx.customerHistory.createMany({ data: history });
      return updated;
    });

    await writeAudit({
      req,
      userId: req.user?.id,
      userRole: req.user?.role,
      action: "customer.update",
      targetType: "customer",
      targetId: customer.id,
      summary: `Pelanggan diperbarui: ${customer.customerNumber}`,
      metadata: { fields: history.map((h) => h.field) },
    });

    res.json({ data: customer });
  } catch (err) {
    next(err);
  }
});

const linkSchema = z.object({ deviceId: z.string().min(1) });

customersRouter.post("/:id/link-device", requirePermission("customers:write"), async (req, res, next) => {
  try {
    const parsed = linkSchema.safeParse(req.body);
    if (!parsed.success) throw Errors.validation("Device ID tidak valid");

    const customer = await prisma.customer.findUnique({ where: { id: req.params.id } });
    if (!customer) throw Errors.notFound("Pelanggan tidak ditemukan");

    // Validate the device genuinely exists in GenieACS before linking.
    const device = await getDevice(parsed.data.deviceId);
    const serial = device._deviceId?._SerialNumber ?? null;

    const updated = await prisma.customer.update({
      where: { id: customer.id },
      data: { deviceId: device._id, deviceSerial: serial },
    });

    await writeAudit({
      req,
      userId: req.user?.id,
      userRole: req.user?.role,
      action: "customer.link_device",
      targetType: "customer",
      targetId: customer.id,
      summary: `Perangkat ${device._id} terhubung ke pelanggan ${customer.customerNumber}`,
    });

    res.json({ data: updated });
  } catch (err) {
    next(err);
  }
});

customersRouter.post("/:id/unlink-device", requirePermission("customers:write"), async (req, res, next) => {
  try {
    const customer = await prisma.customer.findUnique({ where: { id: req.params.id } });
    if (!customer) throw Errors.notFound("Pelanggan tidak ditemukan");

    const updated = await prisma.customer.update({
      where: { id: customer.id },
      data: { deviceId: null, deviceSerial: null },
    });

    await writeAudit({
      req,
      userId: req.user?.id,
      userRole: req.user?.role,
      action: "customer.unlink_device",
      targetType: "customer",
      targetId: customer.id,
      summary: `Perangkat dilepas dari pelanggan ${customer.customerNumber}`,
    });

    res.json({ data: updated });
  } catch (err) {
    next(err);
  }
});
