import { Router } from "express";
import { z } from "zod";
import rateLimit from "express-rate-limit";
import { prisma } from "../database/prisma.js";
import { verifyPassword } from "../utils/password.js";
import { createSession, destroySession } from "../services/session.service.js";
import { writeAudit } from "../services/audit.service.js";
import { requireAuth } from "../middleware/auth.js";
import { Errors } from "../utils/errors.js";
import { config } from "../config/index.js";
import type { RoleName } from "../config/permissions.js";

export const authRouter = Router();

const loginLimiter = rateLimit({
  windowMs: config.rateLimit.loginWindowMs,
  max: config.rateLimit.loginMax,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: { code: "RATE_LIMITED", message: "Terlalu banyak percobaan login" } },
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

authRouter.post("/login", loginLimiter, async (req, res, next) => {
  try {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) throw Errors.badRequest("Email atau password tidak valid");
    const { email, password } = parsed.data;

    const user = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });

    // Constant-ish behavior: verify against dummy hash when user absent to
    // reduce user-enumeration timing differences.
    const DUMMY_HASH =
      "$argon2id$v=19$m=19456,t=2,p=1$c29tZXNhbHRzb21lc2FsdA$0000000000000000000000000000000000000000000";
    const ok = user ? await verifyPassword(user.passwordHash, password) : false;
    if (!user) await verifyPassword(DUMMY_HASH, password).catch(() => false);

    if (!user || !ok) {
      await writeAudit({
        req,
        userId: user?.id ?? null,
        userRole: (user?.role as RoleName) ?? null,
        action: "auth.login_failed",
        targetType: "user",
        targetId: email,
        result: "FAILURE",
        summary: "Login gagal",
      });
      throw Errors.unauthorized("Email atau password salah");
    }
    if (user.status !== "ACTIVE") {
      throw Errors.forbidden("Akun dinonaktifkan");
    }

    const sessionId = await createSession(res, user.id, {
      userAgent: req.headers["user-agent"],
      ip: req.ip,
    });
    await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });

    await writeAudit({
      req,
      userId: user.id,
      userRole: user.role as RoleName,
      action: "auth.login",
      targetType: "user",
      targetId: user.id,
      result: "SUCCESS",
      summary: "Login berhasil",
      metadata: { sessionId },
    });

    res.json({
      data: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        themePref: user.themePref,
      },
    });
  } catch (err) {
    next(err);
  }
});

authRouter.post("/logout", requireAuth, async (req, res, next) => {
  try {
    await writeAudit({
      req,
      userId: req.user?.id,
      userRole: req.user?.role,
      action: "auth.logout",
      targetType: "user",
      targetId: req.user?.id,
      result: "SUCCESS",
      summary: "Logout",
    });
    await destroySession(res, req.sessionId);
    res.json({ data: { ok: true } });
  } catch (err) {
    next(err);
  }
});

authRouter.get("/me", requireAuth, async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user) throw Errors.unauthorized();
    res.json({
      data: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        themePref: user.themePref,
      },
    });
  } catch (err) {
    next(err);
  }
});

const themeSchema = z.object({ themePref: z.enum(["light", "dark", "system"]) });
authRouter.patch("/me/preferences", requireAuth, async (req, res, next) => {
  try {
    const parsed = themeSchema.safeParse(req.body);
    if (!parsed.success) throw Errors.badRequest("Preferensi tidak valid");
    await prisma.user.update({
      where: { id: req.user!.id },
      data: { themePref: parsed.data.themePref },
    });
    res.json({ data: { ok: true } });
  } catch (err) {
    next(err);
  }
});
