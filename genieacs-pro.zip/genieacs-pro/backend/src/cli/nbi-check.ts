/**
 * Read-only NBI verification.
 * Safe to run against production: only performs GET requests.
 *
 *   cd backend
 *   cp ../.env.example .env   # fill values
 *   npm install
 *   npm run nbi:check
 */
import { config } from "../config/index.js";

interface CheckResult {
  name: string;
  ok: boolean;
  detail: string;
}

const results: CheckResult[] = [];

async function timedFetch(url: string): Promise<{ status: number; ms: number; body: string }> {
  const started = Date.now();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), config.nbi.timeoutMs);
  try {
    const res = await fetch(url, {
      method: "GET",
      signal: controller.signal,
      headers: { Accept: "application/json" },
    });
    const body = await res.text();
    return { status: res.status, ms: Date.now() - started, body };
  } finally {
    clearTimeout(timer);
  }
}

async function check(name: string, url: string): Promise<void> {
  try {
    const r = await timedFetch(url);
    const snippet = r.body.replace(/\s+/g, " ").slice(0, 300);
    const ok = r.status >= 200 && r.status < 300;
    results.push({
      name,
      ok,
      detail: `HTTP ${r.status} in ${r.ms}ms${snippet ? ` | ${snippet}` : ""}`,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    results.push({ name, ok: false, detail: `ERROR: ${msg}` });
  }
}

async function main(): Promise<void> {
  const base = config.nbi.effectiveUrl.replace(/\/+$/, "");
  // eslint-disable-next-line no-console
  console.log(`\n== GenieACS NBI check ==`);
  // eslint-disable-next-line no-console
  console.log(`Configured: ${config.nbi.url}`);
  // eslint-disable-next-line no-console
  console.log(`Effective : ${base} (timeout ${config.nbi.timeoutMs}ms)\n`);

  await check("GET /devices (projection, limit 1)", `${base}/devices?limit=1&projection=_id,_lastInform`);
  await check("GET /ping", `${base}/ping`);
  await check("GET /tasks (limit 1)", `${base}/tasks?limit=1`);
  await check("GET /faults (limit 1)", `${base}/faults?limit=1`);

  for (const r of results) {
    // eslint-disable-next-line no-console
    console.log(`${r.ok ? "[OK]  " : "[FAIL]"} ${r.name}\n        ${r.detail}`);
  }

  const anyOk = results.some((r) => r.ok);
  const devicesOk = results.find((r) => r.name.startsWith("GET /devices"))?.ok ?? false;

  // eslint-disable-next-line no-console
  console.log("\n== Summary ==");
  if (devicesOk) {
    // eslint-disable-next-line no-console
    console.log("NBI devices endpoint reachable. Proceed with integration.");
  } else if (anyOk) {
    // eslint-disable-next-line no-console
    console.log(
      "NBI reachable but /devices failed. Likely an NBI version or query-syntax difference - inspect the response above.",
    );
  } else {
    // eslint-disable-next-line no-console
    console.log(
      "NBI NOT reachable. Check that GenieACS NBI listens on port 7557 and binds to this interface " +
        "(GENIEACS_NBI_INTERFACE), and that no firewall blocks it.",
    );
    process.exitCode = 1;
  }
}

void main();
