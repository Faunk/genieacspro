import readline from "node:readline";
import { prisma } from "../database/prisma.js";
import { hashPassword, validatePasswordStrength } from "../utils/password.js";
import { config } from "../config/index.js";

/**
 * Create the first Super Admin safely. Idempotent: if any SUPER_ADMIN exists,
 * it refuses (prevents accidental overwrite). Password comes from prompt or
 * BOOTSTRAP_ADMIN_PASSWORD env (delete after use).
 */
async function prompt(question: string, hidden = false): Promise<string> {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => {
    if (hidden) {
      const stdin = process.stdin;
      const onData = (char: Buffer) => {
        const s = char.toString();
        if (s === "\n" || s === "\r" || s === "\u0004") {
          stdin.removeListener("data", onData);
        }
      };
      process.stdout.write(question);
      stdin.on("data", onData);
    } else {
      rl.question(question, (answer) => {
        rl.close();
        resolve(answer.trim());
      });
      return;
    }
    rl.question("", (answer) => {
      rl.close();
      process.stdout.write("\n");
      resolve(answer.trim());
    });
  });
}

async function main(): Promise<void> {
  const existing = await prisma.user.count({ where: { role: "SUPER_ADMIN" } });
  if (existing > 0) {
    // eslint-disable-next-line no-console
    console.error(
      "Sudah ada SUPER_ADMIN. Bootstrap dibatalkan demi keamanan. Gunakan halaman Users untuk menambah admin.",
    );
    process.exit(1);
  }

  const email = (config.bootstrap.email ?? (await prompt("Email Super Admin: "))).toLowerCase();
  const name = config.bootstrap.name ?? (await prompt("Nama: "));
  let password = config.bootstrap.password ?? (await prompt("Password: ", true));

  const weak = validatePasswordStrength(password);
  if (weak) {
    // eslint-disable-next-line no-console
    console.error(`Password lemah: ${weak}`);
    process.exit(1);
  }

  const passwordHash = await hashPassword(password);
  const user = await prisma.user.create({
    data: { email, name, passwordHash, role: "SUPER_ADMIN", status: "ACTIVE" },
  });

  // eslint-disable-next-line no-console
  console.log(`Super Admin dibuat: ${user.email} (${user.id})`);
  await prisma.$disconnect();
}

void main().catch((err) => {
  // eslint-disable-next-line no-console
  console.error(err);
  process.exit(1);
});
