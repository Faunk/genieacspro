import { PrismaClient } from "@prisma/client";
import { logger } from "../utils/logger.js";

/** Single shared Prisma client. */
export const prisma = new PrismaClient({
  log: [{ emit: "event", level: "warn" }, { emit: "event", level: "error" }],
});

prisma.$on("warn" as never, (e: unknown) => logger.warn({ prisma: e }, "prisma warning"));
prisma.$on("error" as never, (e: unknown) => logger.error({ prisma: e }, "prisma error"));

/** Verify DB connectivity. Returns latency in ms or throws. */
export async function checkDatabase(): Promise<{ ok: boolean; latencyMs: number }> {
  const start = Date.now();
  await prisma.$queryRaw`SELECT 1`;
  return { ok: true, latencyMs: Date.now() - start };
}
