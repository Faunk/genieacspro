// One-shot helper: ensure .env has a strong SESSION_SECRET.
// Run from the backend folder:  node scripts/fix-env.mjs
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { randomBytes } from "node:crypto";
import { resolve } from "node:path";

const envPath = resolve(process.cwd(), ".env");

if (!existsSync(envPath)) {
  console.error(".env not found. Create it first:  cp ../env.example .env");
  process.exit(1);
}

let content = readFileSync(envPath, "utf8");
const lines = content.split(/\r?\n/);

const secret = randomBytes(32).toString("hex"); // 64 hex chars
let found = false;

const updated = lines.map((line) => {
  if (/^\s*SESSION_SECRET\s*=/.test(line)) {
    found = true;
    const current = line.split("=").slice(1).join("=").trim();
    if (current.length >= 32 && !/CHANGE_ME/i.test(current)) {
      console.log("SESSION_SECRET already has a strong value; leaving it unchanged.");
      return line;
    }
    console.log("Replacing SESSION_SECRET with a new 64-char random value.");
    return `SESSION_SECRET=${secret}`;
  }
  return line;
});

if (!found) {
  updated.push(`SESSION_SECRET=${secret}`);
  console.log("SESSION_SECRET was missing; appended a new 64-char value.");
}

content = updated.join("\n");
writeFileSync(envPath, content, "utf8");
console.log("Done. .env updated.");
