import * as React from "react";
import { cn } from "@/lib/utils";

type Tone = "default" | "success" | "warning" | "danger" | "muted";

const tones: Record<Tone, string> = {
  default: "bg-[hsl(var(--primary))]/15 text-[hsl(var(--primary))]",
  success: "bg-[hsl(var(--success))]/15 text-[hsl(var(--success))]",
  warning: "bg-[hsl(var(--warning))]/15 text-[hsl(var(--warning))]",
  danger: "bg-[hsl(var(--danger))]/15 text-[hsl(var(--danger))]",
  muted: "bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]",
};

export function Badge({
  tone = "default",
  className,
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & { tone?: Tone }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        tones[tone],
        className,
      )}
      {...props}
    />
  );
}
