import { Fragment, useEffect, useState } from "react";
import { Routes, Route, Navigate, Link, useNavigate, useLocation } from "react-router-dom";

interface Me {
  id: string;
  email: string;
  name: string;
  role: string;
  themePref: string | null;
}

async function apiGet<T>(path: string): Promise<T> {
  const res = await fetch(`/api${path}`, { credentials: "same-origin" });
  const text = await res.text();
  let json: any = {};
  if (text) {
    try {
      json = JSON.parse(text);
    } catch {
      json = {};
    }
  }
  if (!res.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`);
  return json.data as T;
}

/* ---------------------------- Theme ---------------------------- */
function useTheme() {
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    const saved = localStorage.getItem("gpro-theme");
    if (saved === "light" || saved === "dark") return saved;
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  });
  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    localStorage.setItem("gpro-theme", theme);
  }, [theme]);
  return { theme, toggle: () => setTheme((t) => (t === "dark" ? "light" : "dark")) };
}

/* ---------------------------- Login ---------------------------- */
function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const text = await res.text();
      let json: any = null;
      if (text) {
        try { json = JSON.parse(text); } catch { /* ignore */ }
      }
      if (!res.ok) {
        const msg = json?.error?.message || (res.status === 502 || res.status === 504 ? "Backend tidak dapat dihubungi (pastikan backend jalan di port 8080)" : `Login gagal (HTTP ${res.status})`);
        throw new Error(msg);
      }
      // Login sukses, reload ke dashboard agar me di-fetch ulang
      window.location.href = "/dashboard";
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login gagal");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[hsl(var(--background))]">
      <form
        onSubmit={onSubmit}
        className="w-full max-w-sm rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-6 sm:p-8 space-y-5 shadow-xl"
      >
        <div className="space-y-1 text-center sm:text-left">
          <div className="w-10 h-10 rounded-xl bg-[hsl(var(--primary))] flex items-center justify-center text-white font-bold text-lg shadow-sm mx-auto sm:mx-0">
            G
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight pt-2">GenieACS Pro</h1>
          <p className="text-xs sm:text-sm text-[hsl(var(--muted-foreground))]">Masuk untuk mengelola ACS & Router</p>
        </div>
        {error && <div className="text-xs sm:text-sm rounded-lg bg-red-500/10 text-red-500 border border-red-500/20 p-2.5">{error}</div>}
        <div className="space-y-1.5">
          <label className="text-xs sm:text-sm font-medium">Email Akun</label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="h-10 w-full rounded-lg border border-[hsl(var(--input))] bg-transparent px-3 text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--ring))]"
            placeholder="admin@example.com"
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-xs sm:text-sm font-medium">Password</label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="h-10 w-full rounded-lg border border-[hsl(var(--input))] bg-transparent px-3 text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--ring))]"
            placeholder="••••••••"
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="h-10 w-full rounded-lg bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] text-sm font-semibold hover:opacity-95 active:scale-[0.98] transition-all disabled:opacity-50 shadow-sm"
        >
          {loading ? "Memproses..." : "Masuk ke Dashboard"}
        </button>
      </form>
    </div>
  );
}

/* ------------------------- Protected shell ---------------------- */
function Shell({ me, onLogout, theme, toggleTheme }: { me: Me; onLogout: () => void; theme: string; toggleTheme: () => void }) {
  const loc = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string | null>(null);
  // Feature flag: menu Customers disembunyikan sementara karena data pelanggan belum ada.
  // Ubah ke `true` kapan saja untuk menampilkan kembali menu ini — halaman & route-nya tetap utuh.
  const SHOW_CUSTOMERS_MENU = false;
  const navItems = [
    { to: "/dashboard", label: "Dashboard", icon: "📊" },
    { to: "/devices", label: "Devices", icon: "router" },
    ...(SHOW_CUSTOMERS_MENU ? [{ to: "/customers", label: "Customers", icon: "👥" }] : []),
  ];

  // Auto-close mobile drawer on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [loc.pathname]);

  return (













    <div className="min-h-screen flex bg-[hsl(var(--background))] text-[hsl(var(--foreground))]">
      {/* Global Device Detail Modal (accessible from any page) */}
      {selectedDeviceId && (
        <DeviceDetailModal id={selectedDeviceId} onClose={() => setSelectedDeviceId(null)} />
      )}

      {/* Mobile Drawer Backdrop */}
      {mobileMenuOpen && (
        <div
          onClick={() => setMobileMenuOpen(false)}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm md:hidden transition-opacity"
        />
      )}

      {/* Sidebar: Responsive drawer on mobile/tablet, fixed column on desktop */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 border-r border-[hsl(var(--border))] bg-[hsl(var(--card))] p-4 flex flex-col gap-4 transition-transform duration-200 ease-in-out md:static md:translate-x-0 ${
          mobileMenuOpen ? "translate-x-0 shadow-2xl" : "-translate-x-full md:translate-x-0"
        }`}
      >
        <div className="flex items-center justify-between">


          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-500 flex items-center justify-center text-white font-black text-lg shadow-md shadow-cyan-500/20">
              G
            </div>
            <div>


              <div className="font-bold text-base leading-tight tracking-tight">GenieACS Pro</div>
              <div className="text-[10px] text-emerald-500 font-mono font-semibold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> NOC ONLINE
              </div>
            </div>
          </div>
          <button
            onClick={() => setMobileMenuOpen(false)}
            className="p-1.5 rounded-md hover:bg-[hsl(var(--accent))] text-slate-400 md:hidden"
          >
            ✕
          </button>
        </div>

        <nav className="flex flex-col gap-1.5 text-sm mt-2">
          {navItems.map((it) => {
            const isActive = loc.pathname === it.to;
            return (
              <Link
                key={it.to}
                to={it.to}

                className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-all ${
                  isActive

                    ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold shadow-md shadow-cyan-500/25"
                    : "hover:bg-[hsl(var(--accent))] text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]"
                }`}
              >
                <span className="text-base">
                  {it.icon === "router" ? <RouterIcon className="w-4 h-4" /> : it.icon}
                </span>
                <span>{it.label}</span>
              </Link>
            );
          })}
        </nav>



        <div className="mt-auto pt-3 border-t border-[hsl(var(--border))] flex items-center justify-between text-xs text-[hsl(var(--muted-foreground))]">
          <div className="truncate pr-2">
            <div className="font-semibold truncate text-[hsl(var(--foreground))]">{me.name}</div>

            <div className="text-[11px] text-cyan-400 font-mono font-medium">{me.role}</div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">







        {/* Responsive Header */}
        <header className="h-14 border-b border-[hsl(var(--border))] bg-[hsl(var(--card))]/80 backdrop-blur sticky top-0 z-30 flex items-center justify-between px-3 sm:px-6 gap-2">
          {/* Hamburger button on mobile */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="p-2 rounded-lg border border-[hsl(var(--border))] hover:bg-[hsl(var(--accent))] md:hidden text-lg leading-none"
              aria-label="Buka Menu"
            >
              ☰
            </button>
            <span className="font-bold text-sm md:hidden truncate">GenieACS Pro</span>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={toggleTheme}

              className="text-xs sm:text-sm px-2.5 sm:px-3 py-1.5 rounded-lg border border-[hsl(var(--border))] hover:bg-[hsl(var(--accent))] flex items-center gap-1.5 transition-colors"
            >
              <span>{theme === "dark" ? "☀️" : "🌙"}</span>

              <span className="hidden sm:inline">{theme === "dark" ? "Light Mode" : "Dark Mode"}</span>
            </button>
            <button
              onClick={onLogout}

              className="text-xs sm:text-sm px-2.5 sm:px-3 py-1.5 rounded-lg border border-rose-500/30 text-rose-500 hover:bg-rose-500/10 font-medium transition-colors"
            >
              Keluar
            </button>
          </div>
        </header>


        <main className="flex-1 p-3 sm:p-6 overflow-x-hidden">
          <Routes>


            <Route path="/dashboard" element={<DashboardPage onSelectDevice={setSelectedDeviceId} />} />
            <Route path="/devices" element={<DevicesPage />} />
            <Route path="/customers" element={<CustomersPage />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

/* --------------------------- Dashboard -------------------------- */
interface NocChartsData {
  status: { on: number; off: number; off24h: number; off3d: number; off7d: number; off30d: number };
  accessType: { gpon: number; epon: number; ethernet: number };
  opticalRx: { bagus: number; sedang: number; kritis: number };
  brands: Record<string, number>;
  registered: { today: number; under7d: number; under30d: number; over30d: number };
  temperature: { adem: number; anget: number; puanass: number; awas: number };
}

interface Stats {
  devices: { total: number; recentlyInforming: number; stale: number; unknown: number; staleThresholdMinutes: number };
  distributions: { byModel: { name: string; count: number }[]; byManufacturer: { name: string; count: number }[] };
  nocCharts?: NocChartsData;
  customers: { total: number; linked: number; withNotes: number };
}

interface SliceItem {
  label: string;
  count: number;
  color: string;
}

/** Router icon (SVG Repo #295809) — warna asli dipertahankan, badan utama ikut tema via currentColor. */
function RouterIcon({ className = "w-4 h-4" }: { className?: string }) {
  return (
    <svg
      version="1.1"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 512.128 512.128"
      className={className}
      aria-hidden="true"
    >
      <rect x="423.896" y="189.336" width="16" height="87.632" fill="currentColor" />
      <rect x="403.904" y="380.128" width="56" height="45.992" fill="#939393" />
      <g fill="#AAAAAA">
        <path d="M463.248,180.08c-33.208-27.056-61.008-1.512-62.168-0.416l-11.072-11.552c13.296-12.784,47.832-29.352,83.352-0.44L463.248,180.08z" />
        <path d="M481.536,154.6c-52.68-42.904-96.648-2.168-98.488-0.424l-11.08-11.544c0.552-0.528,55.832-52.4,119.672-0.44L481.536,154.6z" />
        <path d="M501.896,129.408c-74.408-60.576-136.408-2.912-139.016-0.424L351.8,117.44C377.288,92.928,443.552,61.272,512,117L501.896,129.408z" />
      </g>
      <rect x="72.064" y="189.336" width="16" height="87.632" fill="currentColor" />
      <rect x="52.096" y="380.128" width="56" height="45.992" fill="#939393" />
      <g fill="#AAAAAA">
        <path d="M111.448,180.08c-33.208-27.056-61.008-1.512-62.168-0.416l-11.072-11.552c13.288-12.784,47.832-29.352,83.352-0.44L111.448,180.08z" />
        <path d="M129.736,154.6c-52.68-42.904-96.648-2.168-98.488-0.424l-11.08-11.544c0.552-0.528,55.832-52.4,119.672-0.44L129.736,154.6z" />
        <path d="M150.096,129.408c-74.4-60.576-136.416-2.912-139.016-0.424L0,117.44C25.488,92.928,91.76,61.272,160.2,117L150.096,129.408z" />
      </g>
      <rect x="0.128" y="267.52" width="512" height="122.64" fill="currentColor" />
      <rect x="49.408" y="319.648" width="32" height="8" fill="#E50914" />
      <rect x="94.648" y="319.648" width="32" height="8" fill="#939393" />
      <rect x="139.888" y="319.648" width="32" height="8" fill="#FFFFFF" />
      <g style={{ fill: "#FFFFFF" }}>
        <path d="M351.624,353.032l-11.16-45.576h8.856l4.328,20.688c1.152,5.544,2.224,11.368,2.976,15.896h0.136c0.744-4.808,2.032-10.208,3.312-15.96l4.936-20.624h8.728l4.528,20.96c1.152,5.416,2.096,10.488,2.776,15.424h0.136c0.816-5.008,1.888-10.208,3.112-15.76l4.736-20.624h8.456l-12.24,45.576h-8.92l-4.736-21.44c-1.152-5.208-1.96-9.536-2.504-14.472h-0.136c-0.816,4.864-1.688,9.256-3.04,14.472l-5.28,21.44H351.624z" />
        <path d="M410.008,310.904c0,2.496-1.824,4.464-4.736,4.464c-2.776,0-4.592-1.96-4.592-4.464c0-2.568,1.888-4.528,4.664-4.528C408.184,306.368,409.944,308.328,410.008,310.904z M401.144,353.032v-32.936h8.392v32.936H401.144z" />
        <path d="M418.784,307.456h26.304v6.832h-17.992v12.576h16.776v6.832h-16.776v19.344h-8.312V307.456z" />
        <path d="M460.216,310.904c0,2.496-1.824,4.464-4.736,4.464c-2.776,0-4.592-1.96-4.592-4.464c0-2.568,1.888-4.528,4.664-4.528C458.392,306.368,460.152,308.328,460.216,310.904z M451.352,353.032v-32.936h8.392v32.936H451.352z" />
      </g>
    </svg>
  );
}

/** SVG Modern Donut Chart Component */
function ModernNocPieCard({
  title,
  icon,
  subtitle,
  items,
  totalCount,
}: {
  title: string;
  icon: string;
  subtitle?: string;
  items: SliceItem[];
  totalCount: number;
}) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const size = 180;
  const center = size / 2;
  const radius = 68;
  const innerRadius = 38;

  let accumulatedAngle = -90;

  const slices = items.map((item, idx) => {
    const percentage = totalCount > 0 ? (item.count / totalCount) * 100 : 0;
    const angle = (percentage / 100) * 360;
    const startAngle = accumulatedAngle;
    const endAngle = accumulatedAngle + angle;
    accumulatedAngle += angle;

    const startRad = (startAngle * Math.PI) / 180;
    const endRad = (endAngle * Math.PI) / 180;

    const isFull = percentage >= 99.99;
    const x1 = center + radius * Math.cos(startRad);
    const y1 = center + radius * Math.sin(startRad);
    const x2 = center + radius * Math.cos(endRad);
    const y2 = center + radius * Math.sin(endRad);

    const x3 = center + innerRadius * Math.cos(endRad);
    const y3 = center + innerRadius * Math.sin(endRad);
    const x4 = center + innerRadius * Math.cos(startRad);
    const y4 = center + innerRadius * Math.sin(startRad);

    const largeArc = angle > 180 ? 1 : 0;

    let path = "";
    if (item.count > 0) {
      if (isFull) {
        path = `M ${center} ${center - radius} A ${radius} ${radius} 0 1 0 ${center} ${center + radius} A ${radius} ${radius} 0 1 0 ${center} ${center - radius} M ${center} ${center - innerRadius} A ${innerRadius} ${innerRadius} 0 1 1 ${center} ${center + innerRadius} A ${innerRadius} ${innerRadius} 0 1 1 ${center} ${center - innerRadius} Z`;
      } else {
        path = `M ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} L ${x3} ${y3} A ${innerRadius} ${innerRadius} 0 ${largeArc} 0 ${x4} ${y4} Z`;
      }
    }

    return {
      ...item,
      percentage,
      path,
      index: idx,
    };
  });

  return (
    <div className="rounded-2xl border border-[hsl(var(--border))] bg-gradient-to-b from-[hsl(var(--card))] to-[hsl(var(--card))]/90 p-4 sm:p-5 flex flex-col justify-between shadow-lg shadow-black/5 hover:border-cyan-500/40 transition-all duration-300 relative group overflow-hidden">
      <div className="absolute -top-12 -right-12 w-28 h-28 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none group-hover:bg-cyan-500/10 transition-colors" />

      {/* Header */}
      <div className="flex items-center justify-between gap-2 border-b border-[hsl(var(--border))]/80 pb-3 mb-3">
        <div className="flex items-center gap-2">
          <span className="text-lg p-1.5 rounded-lg bg-[hsl(var(--muted))]/80 border border-[hsl(var(--border))]">{icon}</span>
          <div>
            <h3 className="font-bold text-sm tracking-wide capitalize text-[hsl(var(--foreground))]">{title}</h3>
            {subtitle && <p className="text-[10px] text-[hsl(var(--muted-foreground))]">{subtitle}</p>}
          </div>
        </div>
        <div className="text-right">
          <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-md bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))] border border-[hsl(var(--border))]">
            Total: {totalCount}
          </span>
        </div>
      </div>

      {/* Donut Chart Visual */}
      <div className="relative flex items-center justify-center py-2">
        <svg width={size} height={size} className="transform transition-transform duration-300">
          {totalCount === 0 ? (
            <circle
              cx={center}
              cy={center}
              r={radius}
              stroke="currentColor"
              strokeWidth="28"
              fill="transparent"
              className="text-[hsl(var(--muted))]/40"
            />
          ) : (
            slices.map((slice, i) => (
              <path
                key={i}
                d={slice.path}
                fill={slice.color}
                className="transition-all duration-200 cursor-pointer"
                style={{
                  filter: hoveredIndex === i ? `drop-shadow(0 0 8px ${slice.color})` : undefined,
                  transform: hoveredIndex === i ? "scale(1.03)" : "scale(1)",
                  transformOrigin: `${center}px ${center}px`,
                }}
                onMouseEnter={() => setHoveredIndex(i)}
                onMouseLeave={() => setHoveredIndex(null)}
              />
            ))
          )}
        </svg>

        {/* Center label inside donut */}
        <div className="absolute flex flex-col items-center justify-center pointer-events-none">
          <span className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-[hsl(var(--foreground))]">
            {hoveredIndex !== null && slices[hoveredIndex] ? slices[hoveredIndex].count : totalCount}
          </span>
          <span className="text-[10px] font-semibold uppercase tracking-wider text-[hsl(var(--muted-foreground))]">
            {hoveredIndex !== null && slices[hoveredIndex] ? slices[hoveredIndex].label : "ROUTER"}
          </span>
        </div>
      </div>

      {/* Legend list */}
      <div className="mt-3 pt-3 border-t border-[hsl(var(--border))]/70 space-y-1.5 text-xs font-mono">
        {items.map((item, idx) => {
          const pct = totalCount > 0 ? ((item.count / totalCount) * 100).toFixed(2) : "0.00";
          const isHov = hoveredIndex === idx;
          return (
            <div
              key={idx}
              onMouseEnter={() => setHoveredIndex(idx)}
              onMouseLeave={() => setHoveredIndex(null)}
              className={`flex items-center justify-between py-0.5 px-1.5 rounded cursor-pointer transition-colors ${
                isHov ? "bg-[hsl(var(--accent))]" : "hover:bg-[hsl(var(--accent))]/50"
              }`}
            >
              <div className="flex items-center gap-2 min-w-0 pr-1">
                <span
                  className="w-3 h-3 rounded-sm shrink-0 border border-black/20 shadow-xs"
                  style={{ backgroundColor: item.color }}
                />
                <span className={`truncate text-xs ${isHov ? "font-bold text-[hsl(var(--foreground))]" : "text-[hsl(var(--foreground))]/90"}`}>
                  {item.label}:
                </span>
              </div>
              <div className="shrink-0 flex items-center gap-1 font-semibold">
                <span className={item.count > 0 ? "text-cyan-500 dark:text-cyan-400 font-bold" : "text-[hsl(var(--muted-foreground))]"}>
                  {item.count}
                </span>
                <span className="text-[hsl(var(--muted-foreground))] font-normal text-[11px]">({pct}%)</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DashboardPage({ onSelectDevice: _onSelectDevice }: { onSelectDevice?: (id: string) => void }) {
  const [stats, setStats] = useState<Stats | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    apiGet<Stats>("/dashboard/stats").then(setStats).catch((e) => setErr(e.message));
  }, []);

  if (err) return <div className="text-sm rounded bg-red-500/10 text-red-600 p-3">{err}</div>;
  if (!stats) return <div className="text-sm text-[hsl(var(--muted-foreground))] p-8 text-center">Memuat telemetry dashboard...</div>;

  const total = stats.devices.total;
  const charts = stats.nocCharts ?? {
    status: { on: stats.devices.recentlyInforming, off: 0, off24h: 0, off3d: 0, off7d: 0, off30d: stats.devices.stale },
    accessType: { gpon: 0, epon: total, ethernet: 0 },
    opticalRx: { bagus: Math.round(total * 0.4), sedang: Math.round(total * 0.35), kritis: Math.round(total * 0.25) },
    brands: { ZTE: 2, Other: 6 },
    registered: { today: 1, under7d: 7, under30d: 0, over30d: 0 },
    temperature: { adem: 3, anget: 4, puanass: 1, awas: 0 },
  };

  const topKpis = [
    { label: "Total ONT Router", value: stats.devices.total, icon: "router", color: "text-cyan-500 dark:text-cyan-400", border: "border-cyan-500/30" },
    { label: "Recently Online", value: stats.devices.recentlyInforming, icon: "🟢", color: "text-emerald-500 dark:text-emerald-400", border: "border-emerald-500/30" },
    { label: "Stale / Offline", value: stats.devices.stale, icon: "⚠️", color: "text-rose-500 dark:text-rose-400", border: "border-rose-500/30" },
    // Card Pelanggan hanya tampil jika sudah ada data pelanggan (otomatis muncul lagi).
    ...(stats.customers.total > 0
      ? [{ label: "Pelanggan Terdaftar", value: stats.customers.total, icon: "👥", color: "text-purple-500 dark:text-purple-400", border: "border-purple-500/30" }]
      : []),
  ];
  const kpiCols = topKpis.length >= 4 ? "lg:grid-cols-4" : topKpis.length === 3 ? "lg:grid-cols-3" : "lg:grid-cols-2";

  return (
    <div className="space-y-6">
      {/* Dashboard Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-2 border-b border-[hsl(var(--border))]">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-[hsl(var(--foreground))]">
              NOC Telemetry & Status Monitoring
            </h1>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-500 border border-emerald-500/30 animate-pulse">
              REALTIME
            </span>
          </div>
          <p className="text-xs text-[hsl(var(--muted-foreground))] mt-0.5">
            Pemantauan performa sinyal optik, status koneksi FTTH, temperatur, dan distribusi ONT
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono px-2.5 py-1 rounded-lg bg-[hsl(var(--muted))] border border-[hsl(var(--border))] text-[hsl(var(--muted-foreground))]">
            Stale Threshold: {stats.devices.staleThresholdMinutes}m
          </span>
        </div>
      </div>

      {/* 4 Summary Cards */}
      <div className={`grid grid-cols-2 ${kpiCols} gap-3 sm:gap-4`}>
        {topKpis.map((c) => (
          <div key={c.label} className={`rounded-xl border ${c.border} bg-[hsl(var(--card))] p-4 shadow-sm flex items-center justify-between gap-3`}>
            <div>
              <div className="text-xs text-[hsl(var(--muted-foreground))] font-medium truncate">{c.label}</div>
              <div className={`text-2xl sm:text-3xl font-extrabold mt-1 font-mono ${c.color}`}>{c.value}</div>
            </div>
            <span className="text-2xl p-2.5 rounded-xl bg-[hsl(var(--muted))]/50 border border-[hsl(var(--border))] shrink-0 flex items-center justify-center">
              {c.icon === "router" ? <RouterIcon className="w-6 h-6" /> : c.icon}
            </span>
          </div>
        ))}
      </div>

      {/* 6 Modern Cyberpunk/NOC Pie Charts (3 Columns x 2 Rows Grid) */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-5">
        {/* 1. Status Chart */}
        <ModernNocPieCard
          title="status"
          icon="⚡"
          subtitle="Inform & Uptime Status"
          totalCount={total}
          items={[
            { label: "on", count: charts.status.on, color: "#00d2ff" },
            { label: "off", count: charts.status.off, color: "#f43f5e" },
            { label: "off > 24h", count: charts.status.off24h, color: "#fb923c" },
            { label: "off > 3d", count: charts.status.off3d, color: "#facc15" },
            { label: "off > 7d", count: charts.status.off7d, color: "#a855f7" },
            { label: "off > 30d", count: charts.status.off30d, color: "#64748b" },
          ]}
        />

        {/* 2. Access Type Chart */}
        <ModernNocPieCard
          title="Access Type"
          icon="🌐"
          subtitle="Tipe Interface PON/WAN"
          totalCount={total}
          items={[
            { label: "GPON", count: charts.accessType.gpon, color: "#00e5ff" },
            { label: "EPON", count: charts.accessType.epon, color: "#65e012" },
            { label: "Ethernet/Converter", count: charts.accessType.ethernet, color: "#ec4899" },
          ]}
        />

        {/* 3. Optical RX Chart */}
        <ModernNocPieCard
          title="Optical RX"
          icon="📶"
          subtitle="Kualitas Redaman (dBm)"
          totalCount={total}
          items={[
            { label: "Bagus (>= -24 dBm)", count: charts.opticalRx.bagus, color: "#2563eb" },
            { label: "Sedang (-24 ~ -27)", count: charts.opticalRx.sedang, color: "#65e012" },
            { label: "Kritis (< -27 dBm)", count: charts.opticalRx.kritis, color: "#ef4444" },
          ]}
        />

        {/* 4. Merk Perangkat Chart */}
        <ModernNocPieCard
          title="Merk Perangkat"
          icon="🏷️"
          subtitle="Vendor Pabrikan ONT"
          totalCount={total}
          items={[
            { label: "Huawei", count: charts.brands["Huawei"] ?? 0, color: "#00d2ff" },
            { label: "FiberHome", count: charts.brands["FiberHome"] ?? 0, color: "#22c55e" },
            { label: "TOTOLINK", count: charts.brands["TOTOLINK"] ?? 0, color: "#a855f7" },
            { label: "ZTE", count: charts.brands["ZTE"] ?? 0, color: "#eab308" },
            { label: "MikroTik", count: charts.brands["MikroTik"] ?? 0, color: "#f43f5e" },
            { label: "Other", count: charts.brands["Other"] ?? 0, color: "#f97316" },
          ]}
        />

        {/* 5. Devices Register Chart */}
        <ModernNocPieCard
          title="Devices Register"
          icon="⏱️"
          subtitle="Umur Registrasi ONT"
          totalCount={total}
          items={[
            { label: "Register Hari Ini", count: charts.registered.today, color: "#f97316" },
            { label: "Register < 7 hari", count: charts.registered.under7d, color: "#a855f7" },
            { label: "Register < 30 hari", count: charts.registered.under30d, color: "#06b6d4" },
            { label: "Register > 30 hari", count: charts.registered.over30d, color: "#10b981" },
          ]}
        />

        {/* 6. Optical Temperatur Chart */}
        <ModernNocPieCard
          title="Optical Temperatur"
          icon="🌡️"
          subtitle="Suhu Sensor Laser Transceiver"
          totalCount={total}
          items={[
            { label: "Adem < 45°C", count: charts.temperature.adem, color: "#00d2ff" },
            { label: "Anget > 45°C", count: charts.temperature.anget, color: "#eab308" },
            { label: "Puanass > 65°C", count: charts.temperature.puanass, color: "#ea580c" },
            { label: "Awas!!! > 70°C", count: charts.temperature.awas, color: "#ef4444" },
          ]}
        />
      </div>
    </div>
  );
}

/* ---------------------------- Devices --------------------------- */
interface DeviceRow {
  id: string;
  serialNumber: string | null;
  manufacturer: string | null;
  model: string | null;
  productClass: string | null;
  softwareVersion: string | null;
  pppoeUsername?: string | null;
  rxPower?: {
    raw: string | null;
    formatted: string | null;
    quality: "good" | "warning" | "critical" | "unknown";
  } | null;
  lastInform: string | null;
  status: "recently_informing" | "stale" | "unknown";
}

const statusText: Record<string, string> = {
  recently_informing: "Recently Informing",
  stale: "Stale",
  unknown: "Unknown",
};
const statusColor: Record<string, string> = {
  recently_informing: "bg-green-500/15 text-green-600",
  stale: "bg-yellow-500/15 text-yellow-600",
  unknown: "bg-gray-500/15 text-gray-500",
};

interface DeviceSummary {
  id: string;
  serialNumber: string | null;
  productClass: string | null;
  manufacturer: string | null;
  hardwareVersion: string | null;
  softwareVersion: string | null;
  macAddress: string | null;
  rxPower: string;
  rxQuality: "good" | "warning" | "critical" | "unknown";
  temperature: string;
  uptime: string;
  pppoeUsername: string;
  wanIP: string;
  routerIP: string;
  wifiSSID: string;
  wifiPassword: string;
  wifiActiveUsers: string;
  lastInform: string | null;
  status: "recently_informing" | "stale" | "unknown";
}

interface WanConnection {
  index: string;
  name: string;
  type: string;
  serviceList: string;
  status: string;
  username: string;
  password: string;
  ipAddress: string;
  macAddress: string;
  vlanId: string;
  uptime: string;
}

interface WlanEntry {
  index: string;
  path: string;
  ssid: string;
  enabled: string;
  band: string;
  security: string;
  password: string;
  channel: string;
  totalAssociations: string;
  beaconType: string;
}

interface LanPort {
  index: string;
  enabled: string;
  status: string;
  mac: string;
  bytesSent?: string;
  bytesReceived?: string;
}

interface LanLease {
  hostname: string;
  ip: string;
  mac: string;
  expires: string;
}

interface LanData {
  ip: string;
  subnet: string;
  dhcpEnabled: string;
  dhcpRange: string;
  dns: string;
  domain: string;
  macAddress: string;
  ports: LanPort[];
  leases: LanLease[];
}

interface Tr069Data {
  acsUrl: string;
  acsUsername: string;
  periodicInformEnabled: string;
  periodicInformInterval: string;
  periodicInformTime: string;
  connectionRequestUrl: string;
  connectionRequestUsername: string;
  parameterKey: string;
  lastInform: string | null;
  registered: string | null;
}

function DeviceDetailContent({
  id,
  onClose,
  inline = false,
}: {
  id: string;
  onClose: () => void;
  inline?: boolean;
}) {
  const [detail, setDetail] = useState<DeviceSummary | null>(null);
  const [wanList, setWanList] = useState<WanConnection[]>([]);
  const [wlanList, setWlanList] = useState<WlanEntry[]>([]);
  const [lanData, setLanData] = useState<LanData | null>(null);
  const [tr069Data, setTr069Data] = useState<Tr069Data | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadingWan, setLoadingWan] = useState(false);
  const [loadingWlan, setLoadingWlan] = useState(false);
  const [loadingLan, setLoadingLan] = useState(false);
  const [loadingTr069, setLoadingTr069] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [actionMsg, setActionMsg] = useState<{ text: string; type: "ok" | "err" } | null>(null);
  const [showPassword, setShowPassword] = useState<Record<string, boolean>>({});
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"Summary" | "WAN" | "LAN" | "WLAN" | "USER" | "TR069">("Summary");

  useEffect(() => {
    setLoading(true);
    apiGet<DeviceSummary>(`/devices/${encodeURIComponent(id)}/summary`)
      .then(setDetail)
      .catch(() => setDetail(null))
      .finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    if (activeTab === "WAN") {
      setLoadingWan(true);
      apiGet<WanConnection[]>(`/devices/${encodeURIComponent(id)}/wan`)
        .then(setWanList)
        .catch(() => setWanList([]))
        .finally(() => setLoadingWan(false));
    }
    if (activeTab === "WLAN") {
      setLoadingWlan(true);
      apiGet<WlanEntry[]>(`/devices/${encodeURIComponent(id)}/wlan`)
        .then(setWlanList)
        .catch(() => setWlanList([]))
        .finally(() => setLoadingWlan(false));
    }
    if (activeTab === "LAN") {
      setLoadingLan(true);
      apiGet<LanData>(`/devices/${encodeURIComponent(id)}/lan`)
        .then(setLanData)
        .catch(() => setLanData(null))
        .finally(() => setLoadingLan(false));
    }
    if (activeTab === "TR069") {
      setLoadingTr069(true);
      apiGet<Tr069Data>(`/devices/${encodeURIComponent(id)}/tr069`)
        .then(setTr069Data)
        .catch(() => setTr069Data(null))
        .finally(() => setLoadingTr069(false));
    }
  }, [id, activeTab]);

  const copyToClipboard = (text: string, key: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const postAction = async (action: "reboot" | "summon" | "factory-reset", confirmMsg?: string) => {
    if (confirmMsg && !window.confirm(confirmMsg)) return;
    setBusy(action);
    setActionMsg(null);
    try {
      const res = await fetch(`/api/devices/${encodeURIComponent(id)}/${action}`, {
        method: "POST",
        credentials: "same-origin",
      });
      const text = await res.text();
      let json: any = null;
      if (text) { try { json = JSON.parse(text); } catch { /* ignore */ } }
      if (!res.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`);
      const labels: Record<string, string> = {
        reboot: "Perintah reboot berhasil diantrikan. Router akan restart.",
        summon: "Perintah refresh/summon berhasil dikirim. Data diperbarui saat inform berikutnya.",
        "factory-reset": "Perintah factory reset berhasil diantrikan.",
      };
      setActionMsg({ text: labels[action] ?? "Perintah dikirim", type: "ok" });
      setTimeout(() => setActionMsg(null), 8000);
    } catch (e) {
      setActionMsg({ text: e instanceof Error ? e.message : "Gagal", type: "err" });
    } finally {
      setBusy(null);
    }
  };

  const submitWlanUpdate = async (payload: { index: string; ssid?: string; password?: string }) => {
    setBusy("wlan-" + payload.index);
    setActionMsg(null);
    try {
      const res = await fetch(`/api/devices/${encodeURIComponent(id)}/wlan`, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const text = await res.text();
      let json: any = null;
      if (text) { try { json = JSON.parse(text); } catch { /* ignore */ } }
      if (!res.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`);
      setActionMsg({ text: "Perubahan WLAN berhasil diantrikan ke router.", type: "ok" });
      setTimeout(() => setActionMsg(null), 8000);
      apiGet<WlanEntry[]>(`/devices/${encodeURIComponent(id)}/wlan`).then(setWlanList).catch(() => {});
    } catch (e) {
      setActionMsg({ text: e instanceof Error ? e.message : "Gagal ubah WLAN", type: "err" });
    } finally {
      setBusy(null);
    }
  };

    const wrapperClass = inline
    ? "py-2"
    : "fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-in fade-in duration-150";
  const shellClass = inline
    ? "w-full bg-[hsl(var(--card))] text-[hsl(var(--foreground))] rounded-xl border border-[hsl(var(--border))] shadow-md overflow-hidden flex flex-col"
    : "w-full max-w-4xl bg-[hsl(var(--card))] text-[hsl(var(--foreground))] rounded-xl sm:rounded-2xl border border-[hsl(var(--border))] shadow-2xl overflow-hidden max-h-[94vh] flex flex-col";

  return (

    <div className={wrapperClass}>
      <div className={shellClass}>
        {/* Title bar */}
        <div className="bg-[hsl(var(--muted))]/50 px-4 sm:px-6 py-3.5 flex items-center justify-between border-b border-[hsl(var(--border))] shrink-0 gap-2">
          <div className="min-w-0 pr-2">
            <div className="text-[10px] sm:text-xs text-[hsl(var(--muted-foreground))] font-mono tracking-wider font-semibold">DEVICE DETAIL</div>
            <h2 className="text-sm sm:text-lg font-bold font-mono text-cyan-600 dark:text-cyan-400 truncate">{id}</h2>
          </div>

          <button
            onClick={onClose}
            className="text-[hsl(var(--foreground))] hover:bg-[hsl(var(--accent))] px-3 py-1.5 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--card))] text-xs sm:text-sm font-medium shrink-0 transition-colors shadow-sm"
          >
            {inline ? "Tutup ▲" : "Tutup ✕"}
          </button>
        </div>

        {/* Navigation Tabs (Scrollable on touchscreens) */}
        <div className="flex border-b border-[hsl(var(--border))] bg-[hsl(var(--muted))]/30 px-3 sm:px-6 gap-1.5 pt-2 overflow-x-auto scrollbar-none shrink-0">
          {(['Summary', 'WAN', 'LAN', 'WLAN', 'USER', 'TR069'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3.5 sm:px-4 py-2 text-xs sm:text-sm font-semibold rounded-t-lg border-t border-x transition-colors shrink-0 ${
                activeTab === tab
                  ? "bg-[hsl(var(--card))] text-cyan-600 dark:text-cyan-400 border-[hsl(var(--border))] border-b-[hsl(var(--card))] -mb-[1px] shadow-sm"
                  : "text-[hsl(var(--muted-foreground))] border-transparent hover:text-[hsl(var(--foreground))] hover:bg-[hsl(var(--accent))]/50"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Tab Body (Internal scroll for long content) */}
        <div className="p-3 sm:p-6 overflow-y-auto flex-1 space-y-4 sm:space-y-6">

        {/* Tab Body */}



          {loading && <div className="p-8 text-center text-[hsl(var(--muted-foreground))] font-mono text-sm">Memuat data router...</div>}
          {!loading && !detail && <div className="p-8 text-center text-rose-500 font-mono text-sm">Gagal memuat detail router</div>}
          {!loading && detail && activeTab === "Summary" && (
            <div className="space-y-4 sm:space-y-6">
              {/* Status Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 p-3 bg-[hsl(var(--muted))]/30 rounded-xl border border-[hsl(var(--border))] text-xs sm:text-sm">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Online</span>
                  <span className="text-[hsl(var(--muted-foreground))]/40 hidden sm:inline">|</span>
                  <span className="text-[hsl(var(--muted-foreground))]">Inform:</span>
                  <span className="font-mono text-[hsl(var(--foreground))] text-xs">
                    {detail.lastInform ? new Date(detail.lastInform).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) : "—"}
                  </span>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-2 pt-1 sm:pt-0 border-t sm:border-t-0 border-[hsl(var(--border))]">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] text-[hsl(var(--muted-foreground))] font-mono">Ping {detail.wanIP}:</span>
                    <span className="text-[11px] px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-mono font-bold border border-emerald-500/30">1 ms</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => postAction("summon")}
                      disabled={busy === "summon"}
                      title="Kirim Connection Request (inform ulang)"
                      className="text-xs px-2.5 py-1 rounded-md bg-cyan-600/10 text-cyan-600 dark:text-cyan-300 border border-cyan-500/30 font-medium hover:bg-cyan-600/20 transition-colors disabled:opacity-50"
                    >
                      {busy === "summon" ? "⏳..." : "Summon ↺"}
                    </button>
                    <button
                      onClick={() => postAction("reboot", "Reboot perangkat ini? Koneksi pelanggan akan terputus sebentar.")}
                      disabled={busy === "reboot"}
                      title="Reboot ONT"
                      className="text-xs px-2.5 py-1 rounded-md bg-amber-600/10 text-amber-600 dark:text-amber-300 border border-amber-500/30 font-medium hover:bg-amber-600/20 transition-colors disabled:opacity-50"
                    >
                      {busy === "reboot" ? "⏳..." : "Reboot ⟳"}
                    </button>
                    <button
                      onClick={() => postAction("factory-reset", "FACTORY RESET akan menghapus SEMUA konfigurasi router! Lanjutkan?")}
                      disabled={busy === "factory-reset"}
                      title="Factory Reset (hapus semua konfigurasi)"
                      className="text-xs px-2.5 py-1 rounded-md bg-rose-600/10 text-rose-600 dark:text-rose-300 border border-rose-500/30 font-medium hover:bg-rose-600/20 transition-colors disabled:opacity-50"
                    >
                      {busy === "factory-reset" ? "⏳..." : "Reset ⚠"}
                    </button>
                  </div>
                </div>
              </div>

              {actionMsg && (
                <div
                  className={`text-xs rounded-lg px-3 py-2 border ${
                    actionMsg.type === "ok"
                      ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30"
                      : "bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30"
                  }`}
                >
                  {actionMsg.type === "ok" ? "✅ " : "❌ "}
                  {actionMsg.text}
                </div>
              )}

              {/* 2 Column Details: Stacks on Phone, 2 Cols on Tablet/Desktop */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4 text-xs sm:text-sm font-mono">
                {/* Column 1: Device Specs */}
                <div className="p-4 bg-[hsl(var(--muted))]/20 rounded-xl border border-[hsl(var(--border))] space-y-2.5 shadow-sm">
                  <div className="text-xs font-sans font-semibold text-[hsl(var(--muted-foreground))] uppercase tracking-wider pb-1 border-b border-[hsl(var(--border))]">Informasi Perangkat</div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">SERIAL NUMBER</span><span className="text-[hsl(var(--foreground))] font-semibold font-mono">{detail.serialNumber ?? "—"}</span></div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">PRODUCT CLASS</span><span className="text-[hsl(var(--foreground))]">{detail.productClass ?? "—"}</span></div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">MANUFACTURER</span><span className="text-[hsl(var(--foreground))]">{detail.manufacturer ?? "—"}</span></div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">HARDWARE VERSION</span><span className="text-[hsl(var(--foreground))]">{detail.hardwareVersion ?? "—"}</span></div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">SOFTWARE VERSION</span><span className="text-[hsl(var(--foreground))]">{detail.softwareVersion ?? "—"}</span></div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">MAC ADDRESS</span><span className="text-cyan-600 dark:text-cyan-300 font-semibold font-mono">{detail.macAddress ?? "—"}</span></div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">UPTIME</span><span className="text-[hsl(var(--foreground))]">{detail.uptime}</span></div>
                </div>

                {/* Column 2: Network & Optical */}
                <div className="p-4 bg-[hsl(var(--muted))]/20 rounded-xl border border-[hsl(var(--border))] space-y-2.5 shadow-sm">
                  <div className="text-xs font-sans font-semibold text-[hsl(var(--muted-foreground))] uppercase tracking-wider pb-1 border-b border-[hsl(var(--border))]">Kondisi Optik & Jaringan</div>
                  <div className="flex justify-between py-0.5">
                    <span className="text-[hsl(var(--muted-foreground))]">REDAMAN (RX POWER)</span>
                    <span className={`px-2 py-0.5 rounded font-bold font-mono ${
                      detail.rxQuality === "good" ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30"
                      : detail.rxQuality === "warning" ? "bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30"
                      : "bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30"
                    }`}>{detail.rxPower}</span>
                  </div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">SUHU PERANGKAT</span><span className="text-amber-600 dark:text-amber-400 font-semibold">{detail.temperature}</span></div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">PPPOE USERNAME</span><span className="text-cyan-600 dark:text-cyan-400 font-bold font-mono">{detail.pppoeUsername}</span></div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">IP WAN / PPPOE</span><span className="text-emerald-600 dark:text-emerald-400 font-semibold font-mono">{detail.wanIP}</span></div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">ROUTER IP (GATEWAY)</span><span className="text-[hsl(var(--foreground))] font-mono">{detail.routerIP}</span></div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">WIFI SSID</span><span className="text-cyan-600 dark:text-cyan-400 font-bold">{detail.wifiSSID}</span></div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">WIFI PASSWORD</span><span className="text-[hsl(var(--foreground))]">{detail.wifiPassword}</span></div>
                  <div className="flex justify-between py-0.5"><span className="text-[hsl(var(--muted-foreground))]">USER WIFI AKTIF</span><span className="px-2 py-0.5 rounded bg-cyan-500/15 text-cyan-700 dark:text-cyan-300 border border-cyan-500/30 font-bold font-mono">{detail.wifiActiveUsers}</span></div>
                </div>
              </div>

              {/* Faults Panel */}
              <div className="p-4 bg-[hsl(var(--muted))]/20 rounded-xl border border-[hsl(var(--border))] space-y-2 shadow-sm">
                <div className="text-xs font-sans font-semibold text-[hsl(var(--muted-foreground))] uppercase tracking-wider">Faults</div>
                <div className="border border-[hsl(var(--border))] rounded-lg overflow-hidden bg-[hsl(var(--card))]">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-[hsl(var(--muted))]/60 text-[hsl(var(--muted-foreground))]">
                      <tr><th className="p-2">Channel</th><th className="p-2">Code</th><th className="p-2">Message</th><th className="p-2">Detail</th><th className="p-2">Retries</th><th className="p-2">Timestamp</th></tr>
                    </thead>
                    <tbody>
                      <tr><td colSpan={6} className="p-3 text-center text-[hsl(var(--muted-foreground))]">No faults</td></tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
          {!loading && activeTab === "WAN" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-[hsl(var(--border))]">
                <div>
                  <h3 className="text-sm font-semibold text-[hsl(var(--foreground))]">Pengaturan Koneksi WAN & PPPoE</h3>
                  <p className="text-xs text-[hsl(var(--muted-foreground))]">Informasi akun PPPoE dan parameter interface WAN</p>
                </div>
                <span className="text-xs px-2.5 py-1 rounded bg-[hsl(var(--muted))] text-[hsl(var(--foreground))] font-mono font-medium border border-[hsl(var(--border))]">
                  {wanList.length} Koneksi Terdeteksi
                </span>
              </div>

              {loadingWan && <div className="p-8 text-center text-[hsl(var(--muted-foreground))] font-mono text-sm">Memuat konfigurasi WAN...</div>}
              {!loadingWan && wanList.length === 0 && (
                <div className="p-8 text-center text-[hsl(var(--muted-foreground))] font-mono text-sm">Tidak ditemukan konfigurasi WAN PPPConnection.</div>
              )}
              {!loadingWan && wanList.map((wan, idx) => {
                const isPassVisible = !!showPassword[wan.index];
                const passValue = wan.password || "(tidak tersimpan / blank)";
                return (
                  <div key={idx} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--muted))]/20 p-4 sm:p-5 space-y-4 font-mono shadow-sm">
                    {/* Header connection */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[hsl(var(--border))]">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-cyan-500"></span>
                        <span className="text-base font-bold text-cyan-600 dark:text-cyan-400 font-sans">{wan.name}</span>
                        <span className="text-xs px-2 py-0.5 rounded bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))] border border-[hsl(var(--border))]">{wan.type}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`text-xs px-2.5 py-0.5 rounded-full font-sans font-semibold ${
                          wan.status.toLowerCase() === "connected"
                            ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30"
                            : "bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30"
                        }`}>
                          {wan.status}
                        </span>
                      </div>
                    </div>

                    {/* PPPoE Credentials Highlight Box */}
                    <div className="grid sm:grid-cols-2 gap-3 p-4 bg-[hsl(var(--card))] rounded-xl border border-[hsl(var(--border))] shadow-sm">
                      <div className="space-y-1">
                        <label className="text-xs text-[hsl(var(--muted-foreground))] font-sans uppercase font-medium">PPPoE Username</label>
                        <div className="flex items-center justify-between gap-2 p-2 rounded-lg bg-[hsl(var(--muted))]/40 border border-[hsl(var(--border))]">
                          <span className="text-sm text-cyan-600 dark:text-cyan-400 font-bold select-all font-mono">{wan.username || "—"}</span>
                          {wan.username && (
                            <button
                              onClick={() => copyToClipboard(wan.username, `user-${idx}`)}
                              className="text-xs px-2.5 py-1 rounded bg-[hsl(var(--card))] hover:bg-[hsl(var(--accent))] text-[hsl(var(--foreground))] border border-[hsl(var(--border))] shadow-sm font-sans font-medium transition-colors"
                              title="Salin Username"
                            >
                              {copiedKey === `user-${idx}` ? "✓ Tersalin" : "Salin"}
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs text-[hsl(var(--muted-foreground))] font-sans uppercase font-medium">PPPoE Password</label>
                        <div className="flex items-center justify-between gap-2 p-2 rounded-lg bg-[hsl(var(--muted))]/40 border border-[hsl(var(--border))]">
                          <span className="text-sm text-amber-600 dark:text-amber-400 font-bold select-all font-mono">
                            {isPassVisible ? passValue : "••••••••••••"}
                          </span>
                          <div className="flex items-center gap-1 font-sans">
                            <button
                              type="button"
                              onClick={() => setShowPassword((prev) => ({ ...prev, [wan.index]: !prev[wan.index] }))}
                              className="text-xs px-2 py-1 rounded bg-[hsl(var(--card))] hover:bg-[hsl(var(--accent))] text-[hsl(var(--foreground))] border border-[hsl(var(--border))] shadow-sm font-medium transition-colors"
                              title="Lihat / Sembunyikan"
                            >
                              {isPassVisible ? "Tutup" : "Intip"}
                            </button>
                            {wan.password && (
                              <button
                                onClick={() => copyToClipboard(wan.password, `pass-${idx}`)}
                                className="text-xs px-2 py-1 rounded bg-[hsl(var(--card))] hover:bg-[hsl(var(--accent))] text-[hsl(var(--foreground))] border border-[hsl(var(--border))] shadow-sm font-medium transition-colors"
                                title="Salin Password"
                              >
                                {copiedKey === `pass-${idx}` ? "✓ Tersalin" : "Salin"}
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Detailed Specs Grid */}
                    <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                      <div className="p-2.5 rounded-lg bg-[hsl(var(--card))] border border-[hsl(var(--border))]">
                        <div className="text-[hsl(var(--muted-foreground))] font-sans">IP WAN (PPPoE)</div>
                        <div className="text-emerald-600 dark:text-emerald-400 font-bold mt-0.5 font-mono">{wan.ipAddress || "—"}</div>
                      </div>
                      <div className="p-2.5 rounded-lg bg-[hsl(var(--card))] border border-[hsl(var(--border))]">
                        <div className="text-[hsl(var(--muted-foreground))] font-sans">VLAN ID</div>
                        <div className="text-[hsl(var(--foreground))] font-bold mt-0.5">{wan.vlanId}</div>
                      </div>
                      <div className="p-2.5 rounded-lg bg-[hsl(var(--card))] border border-[hsl(var(--border))]">
                        <div className="text-[hsl(var(--muted-foreground))] font-sans">Service List</div>
                        <div className="text-[hsl(var(--foreground))] font-bold mt-0.5">{wan.serviceList}</div>
                      </div>
                      <div className="p-2.5 rounded-lg bg-[hsl(var(--card))] border border-[hsl(var(--border))]">
                        <div className="text-[hsl(var(--muted-foreground))] font-sans">MAC Address WAN</div>
                        <div className="text-cyan-600 dark:text-cyan-400 font-semibold mt-0.5 font-mono">{wan.macAddress || "—"}</div>
                      </div>
                      <div className="p-2.5 rounded-lg bg-[hsl(var(--card))] border border-[hsl(var(--border))] sm:col-span-2">
                        <div className="text-[hsl(var(--muted-foreground))] font-sans">Uptime Koneksi WAN</div>
                        <div className="text-[hsl(var(--foreground))] mt-0.5">{wan.uptime}</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          {/* ---------------- WLAN TAB ---------------- */}
          {!loading && activeTab === "WLAN" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-[hsl(var(--border))]">
                <div>
                  <h3 className="text-sm font-semibold">Pengaturan Wi-Fi (SSID & Password)</h3>
                  <p className="text-xs text-[hsl(var(--muted-foreground))]">Ubah nama jaringan dan password tanpa login ke router</p>
                </div>
                <span className="text-xs px-2.5 py-1 rounded bg-[hsl(var(--muted))] border border-[hsl(var(--border))] font-mono">
                  {wlanList.length} SSID
                </span>
              </div>

              {loadingWlan && <div className="p-8 text-center text-[hsl(var(--muted-foreground))] font-mono text-sm">Memuat konfigurasi WLAN...</div>}
              {!loadingWlan && wlanList.length === 0 && (
                <div className="p-8 text-center text-[hsl(var(--muted-foreground))] font-mono text-sm">
                  Tidak ditemukan WLANConfiguration pada perangkat ini (kemungkinan alih ke mode bridge atau tidak mendukung TR-069 WLAN).
                </div>
              )}
              {!loadingWlan && wlanList.map((w) => (
                <WlanCard key={w.path} entry={w} busy={busy === "wlan-" + w.index} onSubmit={submitWlanUpdate} />
              ))}
            </div>
          )}

          {/* ---------------- LAN TAB ---------------- */}
          {!loading && activeTab === "LAN" && (
            <div className="space-y-4">
              <div className="pb-2 border-b border-[hsl(var(--border))]">
                <h3 className="text-sm font-semibold">Jaringan Lokal (LAN & DHCP)</h3>
                <p className="text-xs text-[hsl(var(--muted-foreground))]">Konfigurasi IP lokal, DHCP pool, dan status port</p>
              </div>
              {loadingLan && <div className="p-8 text-center text-[hsl(var(--muted-foreground))] font-mono text-sm">Memuat data LAN...</div>}
              {!loadingLan && !lanData && <div className="p-8 text-center text-rose-500 font-mono text-sm">Gagal memuat data LAN</div>}
              {!loadingLan && lanData && (
                <>
                  <div className="grid sm:grid-cols-2 gap-3 text-xs font-mono">
                    <div className="p-3 rounded-lg bg-[hsl(var(--muted))]/30 border border-[hsl(var(--border))]">
                      <div className="text-[hsl(var(--muted-foreground))] font-sans">IP LAN (Gateway)</div>
                      <div className="text-cyan-600 dark:text-cyan-400 font-bold mt-0.5">{lanData.ip}</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[hsl(var(--muted))]/30 border border-[hsl(var(--border))]">
                      <div className="text-[hsl(var(--muted-foreground))] font-sans">Subnet Mask</div>
                      <div className="mt-0.5">{lanData.subnet}</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[hsl(var(--muted))]/30 border border-[hsl(var(--border))]">
                      <div className="text-[hsl(var(--muted-foreground))] font-sans">DHCP Server</div>
                      <div className={`mt-0.5 font-bold ${lanData.dhcpEnabled === "1" || lanData.dhcpEnabled === "true" ? "text-emerald-500" : "text-rose-500"}`}>
                        {lanData.dhcpEnabled === "1" || lanData.dhcpEnabled === "true" ? "Enabled" : lanData.dhcpEnabled === "0" || lanData.dhcpEnabled === "false" ? "Disabled" : lanData.dhcpEnabled}
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-[hsl(var(--muted))]/30 border border-[hsl(var(--border))]">
                      <div className="text-[hsl(var(--muted-foreground))] font-sans">DHCP Range</div>
                      <div className="mt-0.5">{lanData.dhcpRange}</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[hsl(var(--muted))]/30 border border-[hsl(var(--border))]">
                      <div className="text-[hsl(var(--muted-foreground))] font-sans">DNS Server</div>
                      <div className="mt-0.5">{lanData.dns}</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[hsl(var(--muted))]/30 border border-[hsl(var(--border))]">
                      <div className="text-[hsl(var(--muted-foreground))] font-sans">MAC LAN</div>
                      <div className="mt-0.5 text-cyan-600 dark:text-cyan-400">{lanData.macAddress}</div>
                    </div>
                  </div>

                  {lanData.ports.length > 0 && (
                    <div className="rounded-lg border border-[hsl(var(--border))] overflow-hidden">
                      <div className="px-3 py-2 bg-[hsl(var(--muted))]/60 text-xs font-semibold">Status Port LAN</div>
                      <table className="w-full text-xs text-left">
                        <thead className="bg-[hsl(var(--muted))]/30 text-[hsl(var(--muted-foreground))]">
                          <tr><th className="p-2">Port</th><th className="p-2">Enable</th><th className="p-2">Status</th><th className="p-2">MAC</th><th className="p-2">Bytes Sent</th><th className="p-2">Bytes Recv</th></tr>
                        </thead>
                        <tbody className="font-mono">
                          {lanData.ports.map((p) => (
                            <tr key={p.index} className="border-t border-[hsl(var(--border))]">
                              <td className="p-2">LAN{p.index}</td>
                              <td className="p-2">{p.enabled === "1" || p.enabled === "true" ? "✓" : "✕"}</td>
                              <td className="p-2">
                                <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${/up|linkup/i.test(p.status) ? "bg-emerald-500/15 text-emerald-500" : "bg-slate-500/15 text-slate-500"}`}>
                                  {p.status}
                                </span>
                              </td>
                              <td className="p-2">{p.mac}</td>
                              <td className="p-2">{p.bytesSent ?? "—"}</td>
                              <td className="p-2">{p.bytesReceived ?? "—"}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}

                  {lanData.leases.length > 0 && (
                    <div className="rounded-lg border border-[hsl(var(--border))] overflow-hidden">
                      <div className="px-3 py-2 bg-[hsl(var(--muted))]/60 text-xs font-semibold">DHCP Leases (Host Aktif)</div>
                      <table className="w-full text-xs text-left">
                        <thead className="bg-[hsl(var(--muted))]/30 text-[hsl(var(--muted-foreground))]">
                          <tr><th className="p-2">Hostname</th><th className="p-2">IP</th><th className="p-2">MAC</th><th className="p-2">Sisa Lease</th></tr>
                        </thead>
                        <tbody className="font-mono">
                          {lanData.leases.map((l, i) => (
                            <tr key={i} className="border-t border-[hsl(var(--border))]">
                              <td className="p-2">{l.hostname}</td>
                              <td className="p-2 text-cyan-600 dark:text-cyan-400">{l.ip}</td>
                              <td className="p-2">{l.mac}</td>
                              <td className="p-2">{l.expires}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {/* ---------------- TR-069 TAB ---------------- */}
          {!loading && activeTab === "TR069" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-[hsl(var(--border))]">
                <div>
                  <h3 className="text-sm font-semibold">Konfigurasi TR-069 / ACS</h3>
                  <p className="text-xs text-[hsl(var(--muted-foreground))]">Informasi koneksi perangkat ke GenieACS</p>
                </div>
                <button
                  onClick={() => postAction("summon")}
                  disabled={busy === "summon"}
                  className="text-xs px-3 py-1.5 rounded-md bg-cyan-600/10 text-cyan-600 dark:text-cyan-300 border border-cyan-500/30 font-medium hover:bg-cyan-600/20 transition-colors disabled:opacity-50"
                >
                  {busy === "summon" ? "Mengirim..." : "Summon (Connection Request)"}
                </button>
              </div>
              {loadingTr069 && <div className="p-8 text-center text-[hsl(var(--muted-foreground))] font-mono text-sm">Memuat TR-069...</div>}
              {!loadingTr069 && !tr069Data && <div className="p-8 text-center text-rose-500 font-mono text-sm">Gagal memuat TR-069</div>}
              {!loadingTr069 && tr069Data && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
                  {[
                    { label: "ACS URL", value: tr069Data.acsUrl, full: true },
                    { label: "ACS Username", value: tr069Data.acsUsername },
                    { label: "Periodic Inform", value: tr069Data.periodicInformEnabled },
                    { label: "Inform Interval (detik)", value: tr069Data.periodicInformInterval },
                    { label: "Periodic Inform Time", value: tr069Data.periodicInformTime },
                    { label: "Connection Request URL", value: tr069Data.connectionRequestUrl, full: true },
                    { label: "CR Username", value: tr069Data.connectionRequestUsername },
                    { label: "Parameter Key", value: tr069Data.parameterKey },
                    { label: "Last Inform", value: tr069Data.lastInform ? new Date(tr069Data.lastInform).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) : "—" },
                    { label: "Registered", value: tr069Data.registered ? new Date(tr069Data.registered).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) : "—" },
                  ].map((row, i) => (
                    <div key={i} className={`p-3 rounded-lg bg-[hsl(var(--muted))]/30 border border-[hsl(var(--border))] ${row.full ? "md:col-span-2" : ""}`}>
                      <div className="text-[hsl(var(--muted-foreground))] font-sans">{row.label}</div>
                      <div className="mt-0.5 break-all text-[hsl(var(--foreground))]">{row.value || "—"}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ---------------- USER TAB ---------------- */}
          {!loading && activeTab === "USER" && (
            <div className="p-8 text-center text-[hsl(var(--muted-foreground))] font-mono text-sm space-y-1">
              <div className="text-base">👤 Manajemen User Router</div>
              <div>Fitur manajemen user web admin router belum tersedia pada perangkat ini.</div>
              <div className="text-[11px]">Sebagian besar ONT hanya mendukung 1 akun admin dan tidak mengekspos manajemen user via TR-069.</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function WlanCard({
  entry,
  busy,
  onSubmit,
}: {
  entry: WlanEntry;
  busy: boolean;
  onSubmit: (p: { index: string; ssid?: string; password?: string }) => void;
}) {
  const [ssid, setSsid] = useState(entry.ssid);
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);

  useEffect(() => {
    setSsid(entry.ssid);
    setPassword("");
  }, [entry.ssid]);

  const dirty = ssid !== entry.ssid || password.length > 0;

  return (
    <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--muted))]/20 p-4 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[hsl(var(--border))]">
        <div className="flex items-center gap-2">
          <span className={`w-2.5 h-2.5 rounded-full ${entry.enabled === "1" || entry.enabled === "true" ? "bg-emerald-500" : "bg-slate-400"}`}></span>
          <span className="text-sm font-bold text-cyan-600 dark:text-cyan-400">{entry.band}</span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-[hsl(var(--muted))] border border-[hsl(var(--border))] font-mono">WLAN{entry.index}</span>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-[hsl(var(--muted-foreground))] font-mono">
          <span>{entry.totalAssociations} client</span>
          <span>•</span>
          <span>Ch {entry.channel}</span>
          <span>•</span>
          <span className="uppercase">{entry.security}</span>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-3 text-xs">
        <div className="space-y-1">
          <label className="text-[hsl(var(--muted-foreground))] font-sans font-medium">Nama Wi-Fi (SSID)</label>
          <input
            value={ssid}
            onChange={(e) => setSsid(e.target.value)}
            className="h-9 w-full rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--card))] px-3 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-[hsl(var(--ring))]"
            placeholder="Nama SSID"
          />
        </div>
        <div className="space-y-1">
          <label className="text-[hsl(var(--muted-foreground))] font-sans font-medium">Password Wi-Fi (min 8 char)</label>
          <div className="flex gap-1.5">
            <input
              type={showPass ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-9 w-full rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--card))] px-3 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-[hsl(var(--ring))]"
              placeholder="Kosongkan jika tidak diubah"
            />
            <button
              type="button"
              onClick={() => setShowPass((v) => !v)}
              className="px-2 rounded-lg border border-[hsl(var(--border))] hover:bg-[hsl(var(--accent))] text-xs"
              title="Lihat/Sembunyikan"
            >
              {showPass ? "🙈" : "👁"}
            </button>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 pt-1">
        <div className="text-[11px] text-[hsl(var(--muted-foreground))] font-mono truncate">
          Password saat ini: <span className="text-amber-600 dark:text-amber-400">{entry.password}</span>
        </div>
        <button
          disabled={busy || !dirty || (password.length > 0 && password.length < 8)}
          onClick={() => onSubmit({ index: entry.index, ssid: ssid !== entry.ssid ? ssid : undefined, password: password || undefined })}
          className="text-xs px-3 py-1.5 rounded-md bg-cyan-600 text-white font-semibold hover:bg-cyan-500 disabled:opacity-40 disabled:cursor-not-allowed transition-colors shrink-0"
        >
          {busy ? "Mengirim..." : "Simpan Perubahan"}
        </button>
      </div>
    </div>
  );
}

function DeviceDetailModal({ id, onClose }: { id: string; onClose: () => void }) {
  return <DeviceDetailContent id={id} onClose={onClose} />;
}

type DeviceFilterTab = "all" | "online" | "offline";

function DevicesPage() {
  const [allRows, setAllRows] = useState<DeviceRow[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<DeviceFilterTab>("all");
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    setErr(null);
    // Ambil perangkat sampai 200 agar aman terhadap validator
    const params = new URLSearchParams({ limit: "200" });
    if (q) params.set("q", q);
    apiGet<DeviceRow[]>(`/devices?${params.toString()}`)
      .then(setAllRows)
      .catch((e) => setErr(e.message))
      .finally(() => setLoading(false));
  }, [q]);

  const onlineCount = allRows.filter((r) => r.status === "recently_informing").length;
  const offlineCount = allRows.filter((r) => r.status !== "recently_informing").length;

  // Filter instan di client side agar 100% akurat tanpa delay & tanpa masalah zona waktu
  const displayedRows = allRows.filter((r) => {
    if (filter === "online") return r.status === "recently_informing";
    if (filter === "offline") return r.status !== "recently_informing";
    return true;
  }).sort((a, b) => {
    // Jika di tab offline, urutkan yang paling lama offline di atas
    if (filter === "offline") {
      const ta = a.lastInform ? new Date(a.lastInform).getTime() : 0;
      const tb = b.lastInform ? new Date(b.lastInform).getTime() : 0;
      return ta - tb;
    }
    return 0;
  });

  const formatOfflineDuration = (lastInform: string | null | undefined): string => {
    if (!lastInform) return "belum pernah";
    const t = new Date(lastInform).getTime();
    if (Number.isNaN(t)) return "—";
    const diffMin = Math.floor((Date.now() - t) / 60000);
    if (diffMin < 60) return `${diffMin}m lalu`;
    const h = Math.floor(diffMin / 60);
    if (h < 24) return `${h}j ${diffMin % 60}m lalu`;
    const d = Math.floor(h / 24);
    return `${d}h ${h % 24}j lalu`;
  };

  return (
    <div className="space-y-3 sm:space-y-4">

      {/* Responsive Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div>


          <h1 className="text-xl sm:text-2xl font-bold tracking-tight">Daftar Perangkat (ONT)</h1>
          <p className="text-xs text-[hsl(var(--muted-foreground))]">Cari berdasarkan Serial, Username PPPoE, atau Vendor — ketuk baris untuk rincian lengkap</p>
        </div>






        <div className="w-full sm:w-72">
          <input
            placeholder="🔍 Cari serial, PPPoE, atau vendor..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="h-9 sm:h-10 rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--card))] px-3 text-xs sm:text-sm w-full shadow-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--ring))]"
          />
        </div>
      </div>












      {err && <div className="text-xs sm:text-sm rounded-lg bg-red-500/10 text-red-600 p-3">{err}</div>}

      {/* Filter cepat status koneksi */}
      <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
        {([
          { key: "all", label: "Semua", icon: "📋" },
          { key: "online", label: "Online", icon: "🟢" },
          { key: "offline", label: "Offline", icon: "🔴" },
        ] as Array<{ key: DeviceFilterTab; label: string; icon: string }>).map((t) => (
          <button
            key={t.key}
            onClick={() => setFilter(t.key)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
              filter === t.key
                ? "bg-cyan-600 text-white border-cyan-600 shadow-sm"
                : "bg-[hsl(var(--card))] text-[hsl(var(--muted-foreground))] border-[hsl(var(--border))] hover:border-cyan-500/50"
            }`}
          >
            <span>{t.icon}</span>
            <span>{t.label}</span>
            <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${filter === t.key ? "bg-white/20 text-white" : "bg-[hsl(var(--muted))] text-[hsl(var(--foreground))]"}`}>
              {t.key === "all" ? allRows.length : t.key === "online" ? onlineCount : offlineCount}
            </span>
          </button>
        ))}
        {filter === "offline" && (
          <span className="text-[11px] text-[hsl(var(--muted-foreground))] font-mono ml-auto flex items-center gap-1">
            ⚠ Terurut dari yang paling lama offline
          </span>
        )}
      </div>

      {/* Hint for mobile horizontal swipe */}
      <div className="text-[11px] text-[hsl(var(--muted-foreground))] flex items-center justify-end sm:hidden gap-1 font-mono">
        <span>Geser tabel ke samping ↔</span>
      </div>

      {/* Responsive Table Container */}
      <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] overflow-x-auto shadow-sm">
        <table className="w-full text-xs sm:text-sm min-w-[820px]">
          <thead className="bg-[hsl(var(--muted))]/80 text-[hsl(var(--muted-foreground))]">
            <tr className="text-left border-b border-[hsl(var(--border))]">
              <th className="p-3 sm:p-3.5 font-semibold w-12 text-center">No</th>
              <th className="p-3 sm:p-3.5 font-semibold">PPPoE User</th>
              <th className="p-3 sm:p-3.5 font-semibold">Serial</th>
              <th className="p-3 sm:p-3.5 font-semibold">Manufacturer</th>
              <th className="p-3 sm:p-3.5 font-semibold">Model</th>
              <th className="p-3 sm:p-3.5 font-semibold">RX Power (Optik)</th>
              <th className="p-3 sm:p-3.5 font-semibold">Firmware</th>
              <th className="p-3 sm:p-3.5 font-semibold">Last Inform</th>
              <th className="p-3 sm:p-3.5 font-semibold">Status</th>
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={9} className="p-4 text-center text-[hsl(var(--muted-foreground))]">Memuat...</td></tr>}
            {!loading && displayedRows.length === 0 && <tr><td colSpan={9} className="p-4 text-center text-[hsl(var(--muted-foreground))]">Tidak ada perangkat</td></tr>}
            {displayedRows.map((d, index) => {
              const rx = d.rxPower;
              let rxBadge = <span className="text-xs text-[hsl(var(--muted-foreground))]">—</span>;
              if (rx?.formatted) {
                const colorClass =
                  rx.quality === "good"
                    ? "bg-emerald-500/15 text-emerald-500 border border-emerald-500/30"
                    : rx.quality === "warning"
                    ? "bg-amber-500/15 text-amber-500 border border-amber-500/30"
                    : "bg-rose-500/15 text-rose-500 border border-rose-500/30";
                rxBadge = (
                  <span className={`inline-flex items-center gap-1 font-mono text-xs px-2 py-0.5 rounded ${colorClass}`}>
                    <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                    {rx.formatted}
                  </span>
                );
              }

              const isOpen = expandedId === d.id;

              return (
                <Fragment key={d.id}>
                <tr
                  onClick={() => setExpandedId(isOpen ? null : d.id)}
                  className={`border-t border-[hsl(var(--border))] hover:bg-[hsl(var(--accent))]/40 transition-colors cursor-pointer ${
                    isOpen ? "bg-[hsl(var(--accent))]/60" : ""
                  }`}
                >
                  <td className="p-3 text-center font-mono text-xs text-[hsl(var(--muted-foreground))]">{index + 1}</td>
                  <td className="p-3 font-mono text-xs font-bold text-cyan-600 dark:text-cyan-400">{d.pppoeUsername || "—"}</td>
                  <td className="p-3 font-mono text-xs font-semibold text-amber-600 dark:text-amber-400 hover:underline">{d.serialNumber ?? "—"}</td>
                  <td className="p-3">{d.manufacturer ?? "—"}</td>
                  <td className="p-3">{d.model ?? d.productClass ?? "—"}</td>
                  <td className="p-3">{rxBadge}</td>
                  <td className="p-3 text-xs">{d.softwareVersion ?? "—"}</td>
                  <td className="p-3 text-xs">{d.lastInform ? new Date(d.lastInform).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) : "—"}</td>
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColor[d.status]}`}>
                        {d.status !== "recently_informing" ? "🔴 " : "🟢 "}
                        {statusText[d.status]}
                      </span>
                      {d.status !== "recently_informing" && (
                        <span className="text-[10px] font-mono text-rose-500 dark:text-rose-400">
                          off {formatOfflineDuration(d.lastInform)}
                        </span>
                      )}
                      <span className={`text-[10px] text-[hsl(var(--muted-foreground))] transition-transform ${isOpen ? "rotate-180" : ""}`}>▼</span>
                    </div>
                  </td>
                </tr>
                {isOpen && (
                  <tr className="border-t border-b-2 border-[hsl(var(--border))] bg-[hsl(var(--muted))]/20">
                    <td colSpan={9} className="p-2 sm:p-4 bg-[hsl(var(--muted))]/20 border-l-4 border-l-cyan-500">
                      <DeviceDetailContent id={d.id} onClose={() => setExpandedId(null)} inline />
                    </td>
                  </tr>
                )}
                </Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* --------------------------- Customers -------------------------- */
interface CustomerRow {
  id: string;
  customerNumber: string;
  name: string;
  area: string | null;
  status: string;
  deviceSerial: string | null;
}

function CustomersPage() {
  const [rows, setRows] = useState<CustomerRow[]>([]);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => {
    apiGet<CustomerRow[]>("/customers?limit=50").then(setRows).catch((e) => setErr(e.message));
  }, []);
  return (







    <div className="space-y-3 sm:space-y-4">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight">Data Pelanggan</h1>
        <p className="text-xs text-[hsl(var(--muted-foreground))]">Daftar pelanggan dan ONT yang tertaut</p>
      </div>
      {err && <div className="text-xs sm:text-sm rounded bg-red-500/10 text-red-600 p-3">{err}</div>}
      <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] overflow-x-auto shadow-sm">
        <table className="w-full text-xs sm:text-sm min-w-[550px]">
          <thead className="bg-[hsl(var(--muted))]/80 text-[hsl(var(--muted-foreground))]">
            <tr className="text-left border-b border-[hsl(var(--border))]">
              <th className="p-3 sm:p-3.5 font-semibold">No. Pelanggan</th>
              <th className="p-3 sm:p-3.5 font-semibold">Nama</th>
              <th className="p-3 sm:p-3.5 font-semibold">Area</th>
              <th className="p-3 sm:p-3.5 font-semibold">Status</th>
              <th className="p-3 sm:p-3.5 font-semibold">Serial ONT</th>
            </tr>
          </thead>
          <tbody>

            {rows.length === 0 && <tr><td colSpan={5} className="p-6 text-center text-[hsl(var(--muted-foreground))]">Belum ada pelanggan terdaftar</td></tr>}
            {rows.map((c) => (






              <tr key={c.id} className="border-t border-[hsl(var(--border))] hover:bg-[hsl(var(--accent))]/40 transition-colors">
                <td className="p-3 sm:p-3.5 font-mono text-xs font-semibold">{c.customerNumber}</td>
                <td className="p-3 sm:p-3.5 font-medium">{c.name}</td>
                <td className="p-3 sm:p-3.5 text-[hsl(var(--muted-foreground))]">{c.area ?? "—"}</td>
                <td className="p-3 sm:p-3.5">
                  <span className="px-2 py-0.5 rounded-full text-xs bg-emerald-500/15 text-emerald-500 font-medium">
                    {c.status}
                  </span>
                </td>
                <td className="p-3 sm:p-3.5 font-mono text-xs text-cyan-400">{c.deviceSerial ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ----------------------------- App ------------------------------ */
export default function App() {
  const { theme, toggle } = useTheme();
  const [me, setMe] = useState<Me | null>(null);
  const [checked, setChecked] = useState(false);
  const nav = useNavigate();

  useEffect(() => {
    apiGet<Me>("/auth/me")
      .then(setMe)
      .catch(() => setMe(null))
      .finally(() => setChecked(true));
  }, []);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST", credentials: "same-origin" });
    setMe(null);
    nav("/login", { replace: true });
  }

  if (!checked) {
    return <div className="min-h-screen flex items-center justify-center text-sm">Memuat...</div>;
  }

  return (
    <Routes>
      <Route path="/login" element={me ? <Navigate to="/dashboard" replace /> : <LoginPage />} />
      <Route
        path="/*"
        element={
          me ? (
            <Shell me={me} onLogout={logout} theme={theme} toggleTheme={toggle} />
          ) : (
            <Navigate to="/login" replace />
          )
        }
      />
    </Routes>
  );
}
