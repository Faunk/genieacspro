export type DeviceStatus = "recently_informing" | "stale" | "unknown";

export function deviceStatusLabel(s: DeviceStatus): string {
  switch (s) {
    case "recently_informing":
      return "Recently Informing";
    case "stale":
      return "Stale";
    default:
      return "Unknown";
  }
}

export function statusTone(s: DeviceStatus): "success" | "warning" | "muted" {
  if (s === "recently_informing") return "success";
  if (s === "stale") return "warning";
  return "muted";
}

export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    dateStyle: "medium",
    timeStyle: "medium",
  });
}

export function relativeTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return "—";
  const diff = Date.now() - t;
  const min = Math.floor(diff / 60000);
  if (min < 1) return "baru saja";
  if (min < 60) return `${min} menit lalu`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr} jam lalu`;
  const day = Math.floor(hr / 24);
  return `${day} hari lalu`;
}

